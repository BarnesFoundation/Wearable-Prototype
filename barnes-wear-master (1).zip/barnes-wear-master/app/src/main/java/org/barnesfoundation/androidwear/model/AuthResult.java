package org.barnesfoundation.androidwear.model;

import android.text.TextUtils;

public class AuthResult {
    public String access_token = "";
    public String instance_url = "";
    public String id = "";
    public String token_type = "";
    public String issued_at = "";
    public String signature = "";

    public boolean isValid() {
        return !TextUtils.isEmpty(access_token);
    }

    public String getAuthHeader() {
        return token_type + " " + access_token;
    }

    public String getApexRestUrl(final String path) {
        return instance_url + "/services/apexrest/" + path;

    }

    public static class Error {
        public String error = "";
        public String error_description = "";
    }
}
