package org.barnesfoundation.androidwear.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import org.barnesfoundation.androidwear.R;
import org.barnesfoundation.androidwear.model.Item;
import org.barnesfoundation.androidwear.model.SaveForLater;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.barnesfoundation.androidwear.utils.NotificationUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private static final int SCROLL_Y_DISTANCE = 65;

    private final List<Item> ITEMS = new ArrayList<>();
    private final Map<String, Boolean> resetScrollMapItem = new HashMap<>();

    private OnItemClickedListener onItemClickedListener;

    public ItemAdapter(final OnItemClickedListener listener) {
        onItemClickedListener = listener;
    }


    public void setItems(final List<Item> items) {
        synchronized (ITEMS) {
            ITEMS.clear();
            ITEMS.addAll(items);
        }
        notifyDataSetChanged();
    }

    private int getSaveForLaterStateTextId(final Item item) {
        final SaveForLater saveForLater = MiscPref.getObject(MiscPref.ObjectKey.SAVED_ITEMS_MAP, SaveForLater.class);
        final SaveForLater.State state = saveForLater.getState(item);
        switch (state) {
            case SAVING:
                return R.string.saving_item;
            case SAVED:
                return R.string.item_saved;
            default:
                return R.string.save_for_later;
        }
    }

    public void setSaveForLaterState(final Item item, final SaveForLater.State state) {
        final SaveForLater saveForLater = MiscPref.getObject(MiscPref.ObjectKey.SAVED_ITEMS_MAP, SaveForLater.class);
        saveForLater.setState(item, state);
        MiscPref.saveObject(MiscPref.ObjectKey.SAVED_ITEMS_MAP, saveForLater);
        notifyDataSetChanged();
    }

    public synchronized void addItem(final Item item) {
        if (!ITEMS.contains(item)) {
            boolean clearList = false;
            synchronized (ITEMS) {
                for (Item curr : ITEMS) {
                    if (!curr.regionId.equals(item.regionId)) {
                        clearList = true;
                        break;
                    }
                }

                if (clearList) {
                    resetScrollMapItem.clear();
                    ITEMS.clear();
                }

                if (ITEMS.size() == 0) {
                    //just vibrate if this is the first item of this region
                    NotificationUtils.vibrate();
                }

                ITEMS.add(item);
                resetScrollMapItem.put(item.id, true);
            }
            notifyDataSetChanged();
        }
    }

    public void viewAttached(final View view){
        final Object tag = view.getTag();
        if (tag != null && tag instanceof ViewHolder){
            ViewHolder holder = (ViewHolder) tag;
            final Boolean shouldResetScroll = resetScrollMapItem.get(holder.item.id);
            if (shouldResetScroll != null && shouldResetScroll) {
                resetScrollMapItem.put(holder.item.id, false);
                holder.resetScroll();
            }
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter, parent, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        final Item currentItem = ITEMS.get(position);
        holder.setItem(currentItem);
        holder.textView.setText(currentItem.description);

        final int textId = getSaveForLaterStateTextId(currentItem);
        holder.saveForLater.setText(textId);
        holder.saveForLater.setEnabled(textId == R.string.save_for_later);

        Glide.with(holder.imageview.getContext())
                .load(currentItem.imageUrl)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .dontAnimate()
                .into(holder.imageview);
    }

    @Override
    public int getItemCount() {
        return ITEMS.size();
    }

    public interface OnItemClickedListener {
        void saveForLater(Item item);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        Item item;
        private final View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.item_save_for_later) {
                    if (onItemClickedListener != null) {
                        onItemClickedListener.saveForLater(item);
                    }
                }
            }
        };

        View rootView;
        ScrollView scrollView;
        ImageView imageview;
        TextView textView;
        Button saveForLater;

        public ViewHolder(View view) {
            super(view);
            rootView = view;
            scrollView = (ScrollView) view.findViewById(R.id.item_scroll_view);
            imageview = (ImageView) view.findViewById(R.id.item_image);
            textView = (TextView) view.findViewById(R.id.item_main_text);
            saveForLater = (Button) view.findViewById(R.id.item_save_for_later);

            saveForLater.setOnClickListener(onClickListener);
            saveForLater.setVisibility(MiscPref.getBooleanValue(MiscPref.ObjectKey.SAVE_FOR_LATER_DISABLED) ? View.GONE : View.VISIBLE);
        }

        public void resetScroll() {
            scrollView.post(new Runnable() {
                @Override
                public void run() {
                    scrollView.scrollTo(0, 0);
                    scrollView.smoothScrollBy(0, SCROLL_Y_DISTANCE);
                }
            });
        }

        public void setItem(final Item item){
            this.item = item;
            rootView.setTag(this);
        }
    }
}
