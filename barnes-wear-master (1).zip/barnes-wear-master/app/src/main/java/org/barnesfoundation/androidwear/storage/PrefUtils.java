package org.barnesfoundation.androidwear.storage;

import android.content.Context;
import android.content.SharedPreferences;

import org.barnesfoundation.androidwear.utils.ApplicationData;


public final class PrefUtils {

    public static int getIntValue(final String prefFile, final String key) {
        final Context currContext = ApplicationData.getAppContext();
        return currContext.getSharedPreferences(prefFile, Context.MODE_PRIVATE)
                .getInt(key, 0);
    }

    public static float getFloatValue(final String prefFile, final String key) {
        final Context currContext = ApplicationData.getAppContext();
        return currContext.getSharedPreferences(prefFile, Context.MODE_PRIVATE)
                .getFloat(key, 0F);
    }

    public static void setIntValue(final String prefFile, final String key, final int value) {
        final Context currContext = ApplicationData.getAppContext();
        final SharedPreferences sharedPref = currContext.getSharedPreferences(
                prefFile, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(key, value);
        editor.apply();
    }

    public static String getStringValue(final String prefFile, final String key) {
        final Context currContext = ApplicationData.getAppContext();
        return currContext.getSharedPreferences(prefFile, Context.MODE_PRIVATE)
                .getString(key, "");
    }

    public static void setStringValue(final String prefFile, final String key, final String value) {
        final Context currContext = ApplicationData.getAppContext();
        final SharedPreferences sharedPref = currContext.getSharedPreferences(
                prefFile, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static long getLongValue(final String prefFile, final String key) {
        final Context currContext = ApplicationData.getAppContext();
        return currContext.getSharedPreferences(prefFile, Context.MODE_PRIVATE)
                .getLong(key, 0L);
    }

    public static void setLongValue(final String prefFile, final String key, final long value) {
        final Context currContext = ApplicationData.getAppContext();
        final SharedPreferences sharedPref = currContext.getSharedPreferences(
                prefFile, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedPref.edit();
        editor.putLong(key, value);
        editor.apply();
    }

    public static boolean getBooleanValue(final String prefFile, final String key) {
        final Context currContext = ApplicationData.getAppContext();
        return currContext.getSharedPreferences(prefFile, Context.MODE_PRIVATE)
                .getBoolean(key, false);
    }

    public static void setBooleanValue(final String prefFile, final String key, final boolean value) {
        final Context currContext = ApplicationData.getAppContext();
        final SharedPreferences sharedPref = currContext.getSharedPreferences(
                prefFile, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    public static void setFloatValue(final String prefFile, final String key, final float value) {
        final Context currContext = ApplicationData.getAppContext();
        final SharedPreferences sharedPref = currContext.getSharedPreferences(
                prefFile, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedPref.edit();
        editor.putFloat(key, value);
        editor.apply();
    }

    public static void removeValue(final String prefFile, final String key) {
        final Context currContext = ApplicationData.getAppContext();
        final SharedPreferences sharedPref = currContext.getSharedPreferences(
                prefFile, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedPref.edit();
        editor.remove(key);
        editor.apply();
    }

    public static void clear(final String prefFile) {
        ApplicationData.getAppContext()
                .getSharedPreferences(prefFile, Context.MODE_PRIVATE)
                .edit()
                .clear()
                .apply();
    }
}
