package org.barnesfoundation.androidwear.beacons;

import org.altbeacon.beacon.Beacon;
import org.barnesfoundation.androidwear.model.AppConfig;
import org.barnesfoundation.androidwear.model.Item;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.barnesfoundation.androidwear.utils.Log;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import static org.barnesfoundation.androidwear.beacons.BeaconUtils.getBeaconRepresentation;

class BeaconDoubleDelayDetection implements BeaconDetectionBehavior {

    private Beacon sLastBeacon;

    public long getTimer1(){
        final AppConfig appConfig = MiscPref.getObject(MiscPref.ObjectKey.APP_CONFIG, AppConfig.class);
        return appConfig.doubleDelayTimer1;
    }

    public long getTimer2(){
        final AppConfig appConfig = MiscPref.getObject(MiscPref.ObjectKey.APP_CONFIG, AppConfig.class);
        return appConfig.doubleDelayTimer2;
    }

    @Override
    public long getScanPeriod() {
        return 3000;
    }

    @Override
    public long getScanBetweenPeriod() {
        return 2000;
    }

    @Override
    public String getDescription() {
        return "Double delay detection";
    }

    @Override
    public void newBeaconDetected(final Beacon beacon) {
        if (!isSameBeacon(beacon)) {
            Log.r("New beacon detected. Starting " + getTimer1() + " timer.\n\tThe old beacon was: " + getBeaconRepresentation(sLastBeacon) +"\n\tThe new beacon is: " + getBeaconRepresentation(beacon));
            new TimerThread(getTimer1(), new TimerCallback() {
                @Override
                public void timerFinished() {
                    Log.r(getTimer1() + " timer finished for beacon " + getBeaconRepresentation(beacon) + ".\n\tThe current beacon is: " + getBeaconRepresentation(sLastBeacon));
                    if (isSameBeacon(beacon)) {
                        BeaconUtils.fetchItem(beacon);
                    }
                }
            });
        }

        sLastBeacon = beacon;

    }

    @Override
    public void itemsFetched(final Beacon beacon, final List<Item> items) {
        new TimerThread(getTimer2(), new TimerCallback() {
            @Override
            public void timerFinished() {
                Log.r(getTimer2() + " timer finished for beacon " + getBeaconRepresentation(beacon) + "\n\tThe current beacon is: " + getBeaconRepresentation(sLastBeacon));
                if (isSameBeacon(beacon)) {
                    BeaconUtils.postItem(items, beacon);
                }
            }
        });
    }

    private boolean isSameBeacon(final Beacon beacon) {
        return beacon != null && sLastBeacon != null && beacon.equals(sLastBeacon);
    }

    interface TimerCallback {
        void timerFinished();
    }

    private static class TimerThread extends Thread {
        private static final AtomicLong THREAD_ID_GENERATOR = new AtomicLong();

        final long mWaitTime;
        final TimerCallback mCallback;
        final long id = THREAD_ID_GENERATOR.incrementAndGet();

        TimerThread(final long time, final TimerCallback callback) {
            mWaitTime = time;
            mCallback = callback;
            start();
        }

        @Override
        public void run() {
            try {
                Thread.sleep(mWaitTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (mCallback != null && id == THREAD_ID_GENERATOR.get()) {
                mCallback.timerFinished();
            }
        }
    }
}
