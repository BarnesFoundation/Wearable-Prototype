package org.barnesfoundation.androidwear.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.widget.ImageView;

import com.bumptech.glide.request.target.SquaringDrawable;

import org.barnesfoundation.androidwear.utils.Log;

public class CustomImageView extends ImageView{

    private OnImageSetCallback mImageSetCallback;

    public CustomImageView(Context context) {
        super(context);
    }

    public CustomImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void setImageSetCallback(OnImageSetCallback imageSetCallback) {
        this.mImageSetCallback = imageSetCallback;
    }

    @Override
    public void setImageDrawable(final Drawable drawable) {
        super.setImageDrawable(drawable);
        post(new Runnable() {
            @Override
            public void run() {
                if (mImageSetCallback != null){
                    mImageSetCallback.imageSet(drawable);
                }
            }
        });
    }

    public interface OnImageSetCallback {
        void imageSet(Drawable drawable);
    }
}
