package org.barnesfoundation.androidwear.utils;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class GSONSerializers {
    private static final String DATE_FORMAT[] = {"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd HH:mm", "yyyy-MM-dd hh:mm", "yyyy-MM-dd"};


    private static SimpleDateFormat getSimpleDateFormat(final String format) {
        final SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.getDefault());
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf;
    }

    public static class DateSerializer implements JsonSerializer<Date> {
        @Override
        public JsonElement serialize(Date src, Type typeOfSrc, JsonSerializationContext context) {
            final Date dateToFormat = src == null ? new Date() : src;
            final SimpleDateFormat sdf = getSimpleDateFormat(DATE_FORMAT[0]);
            return new JsonPrimitive(sdf.format(dateToFormat));
        }
    }

    public static class DateDeserializer implements JsonDeserializer<Date> {
        @Override
        public Date deserialize(JsonElement je, Type type, JsonDeserializationContext jdc) throws JsonParseException {
            String dateString = je.getAsString();

            for (String format : DATE_FORMAT) {
                try {
                    final SimpleDateFormat sdf = getSimpleDateFormat(format);
                    return sdf.parse(dateString);
                } catch (Exception e) {
                }
            }
            return new Date();
        }
    }
}
