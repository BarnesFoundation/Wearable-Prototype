package org.barnesfoundation.androidwear.beacons;

import org.altbeacon.beacon.Beacon;
import org.barnesfoundation.androidwear.model.Item;

import java.util.List;

public interface BeaconDetectionBehavior {
    long getScanPeriod();
    long getScanBetweenPeriod();
    String getDescription();
    void newBeaconDetected(final Beacon beacon);
    void itemsFetched(final Beacon beacon, final List<Item> items);
}
