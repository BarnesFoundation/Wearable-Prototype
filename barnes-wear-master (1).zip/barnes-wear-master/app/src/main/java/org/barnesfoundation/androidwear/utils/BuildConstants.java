package org.barnesfoundation.androidwear.utils;

public class BuildConstants {

    public static String LOG_BASE_URL = "https://script.google.com/macros/s/AKfycbwiyBmKGIFYqcNIWfvXsXSKWTep8tRzH2G_V_-xtvrU6kWCDM8/";
    public static String LOG_UPLOAD_URL = "postback?func=fileUpload";
    public static String CLIENT_ID = "3MVG9szVa2RxsqBatwXU_Tx7Hui.lvljRlItOAqzZqcL4l1Mm_VRedBiTnnmQSha.ax_HTlDIkKrLC9UfgZ2m";
    public static String CLIENT_SECRET = "6726099961208348726";
    public static String USER_NAME = "tales@happyfuncorp.com";
    public static String USER_SECRET = "zpqd.>NGt17JaiFAH6tHAO5BfpyITazfYjWYR3";

}
