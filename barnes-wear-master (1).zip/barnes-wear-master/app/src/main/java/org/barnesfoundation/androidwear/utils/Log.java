package org.barnesfoundation.androidwear.utils;


import org.barnesfoundation.androidwear.BuildConfig;

/**
 * A debug helper class which allows to disable or enable debugging.
 */
public final class Log {

    private static final String TAG = "BarnesWear";

    private static final LogReporter LOG_REPORTER = new LogReporter();

    /**
     * This class is not intended to be instantiated.
     */
    private Log() {
    }

    public static String getReporterLogs() {
        return LOG_REPORTER.buildLog(false, false).toString();
    }

    public static void flushReporter(){
        LOG_REPORTER.flushBuffer(true);
    }

    /**
     * Logs a debug message.
     *
     * @param message The message to log.
     */
    public static void d(final String message) {
        d(TAG, message);
    }

    public static void r(final String message) {
        d(TAG, message);
        LOG_REPORTER.appendLine(message);
    }

    /**
     * Logs a debug message.
     *
     * @param tag     Identify the source of a log message.
     * @param message The message to log.
     */
    public static void d(final String tag, final String message) {
        if (BuildConfig.WRITE_LOGS) {
            if (tag != null && message != null) {
                android.util.Log.d(tag, message);
            }
        }
    }

    /**
     * Logs an error message.
     *
     * @param message The message to log.
     */
    public static void e(final String message) {
        e(TAG, message);
    }

    /**
     * Logs an error message.
     *
     * @param tag     Identify the source of a log message.
     * @param message The message to log.
     */
    public static void e(final String tag, final String message) {
        if (BuildConfig.WRITE_LOGS) {
            if (tag != null && message != null) {
                android.util.Log.e(tag, message);
            }
        }
    }

    /**
     * Logs an error message.
     *
     * @param message   The message to log.
     * @param throwable The throwable to log.
     */
    public static void e(final String message, final Throwable throwable) {
        e(TAG, message, throwable);
    }

    /**
     * Logs an error message.
     *
     * @param tag       Identify the source of a log message.
     * @param message   The message to log.
     * @param throwable The throwable to log.
     */
    public static void e(final String tag, final String message, final Throwable throwable) {
        if (BuildConfig.WRITE_LOGS) {
            if (tag != null && message != null) {
                android.util.Log.e(tag, message, throwable);
            }
        }
    }

    public static void logException(Throwable throwable) {
        if (BuildConfig.WRITE_LOGS) {
            throwable.printStackTrace();
        }
        try {
            if (BuildConfig.REPORT_CRASHES) {
                //TODO Crashlytics.logException(throwable);
            }
        } catch (Exception e) {

        }
    }
}
