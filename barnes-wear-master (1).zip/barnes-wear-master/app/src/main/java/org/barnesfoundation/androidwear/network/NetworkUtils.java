package org.barnesfoundation.androidwear.network;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;

import org.barnesfoundation.androidwear.model.GenericError;
import org.barnesfoundation.androidwear.utils.ApplicationData;
import org.barnesfoundation.androidwear.utils.JSONUtils;
import org.barnesfoundation.androidwear.utils.Log;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;

public class NetworkUtils {

    private static final int NOTIFICATION_MIN_INTERVAL = 4000;

    private static final String PREFERRED_NETWORK_SSID = "\"BarnesPublic\"";

    private static final AtomicBoolean RECONNECT_IN_PROGRESS = new AtomicBoolean(false);

    public static void reconnectToFirstNetwork() {
        if (!RECONNECT_IN_PROGRESS.get()) {
            new Thread() {
                @Override
                public void run() {
                    RECONNECT_IN_PROGRESS.set(true);
                    try {
                        final Context context = ApplicationData.getAppContext();
                        final WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);

                        Log.r("Network > wifi state before: " + wifiManager.getWifiState());

                        if (wifiManager.getWifiState() != WifiManager.WIFI_STATE_ENABLED ||
                                wifiManager.getWifiState() != WifiManager.WIFI_STATE_ENABLING) {
                            wifiManager.setWifiEnabled(true);
                            //if it's enabling just wait for a few seconds
                            Thread.sleep(4000);
                        }

                        final List<WifiConfiguration> list = wifiManager.getConfiguredNetworks();

                        Log.r("Network > wifi state after: " + wifiManager.getWifiState() + " found networks: " + (list == null ? "null" : list.size()));

                        final WifiConfiguration wifiConfiguration = getWifiConfigurationBySSID(list, PREFERRED_NETWORK_SSID);
                        Log.r("Network > reconnecting to network: " + (wifiConfiguration == null ? "null" : (wifiConfiguration.SSID == null ? "<No SSID>" : wifiConfiguration.SSID) ) + " preferred SSID is: " + PREFERRED_NETWORK_SSID);
                        if (wifiConfiguration != null) {
                            wifiManager.disconnect();
                            wifiManager.enableNetwork(wifiConfiguration.networkId, true);
                            wifiManager.reconnect();
                        }
                    } catch (Exception e) {
                        Log.logException(e);
                    }
                    RECONNECT_IN_PROGRESS.set(false);
                }
            }.start();
        }
    }

    private static WifiConfiguration getWifiConfigurationBySSID(final List<WifiConfiguration> list, final String preferredSSID){
        if (list != null){
            for (WifiConfiguration wifiConfiguration : list){
                if (wifiConfiguration.SSID != null && preferredSSID.equals(wifiConfiguration.SSID)) {
                    return wifiConfiguration;
                }
            }

            if (list.size() > 0){
                return list.get(0);
            }
        }
        return null;
    }

    public static boolean getConnectivityStatus() {
        try {
            final Context mContext = ApplicationData.getAppContext();
            ConnectivityManager connectivity =
                    (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
            return connectivity.getActiveNetworkInfo() != null
                    && connectivity.getActiveNetworkInfo().isAvailable()
                    && connectivity.getActiveNetworkInfo().isConnected();
        } catch (Exception e) {
            Log.logException(e);
            return false;
        }
    }

    public static String getNewtorkStatusMessage() {
        boolean isConnected;
        boolean isAvailable;
        boolean isWiFi;
        try {
            final ConnectivityManager cm = (ConnectivityManager) ApplicationData.getAppContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            final NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();
            isAvailable = activeNetwork != null && activeNetwork.isAvailable();
            isWiFi = activeNetwork != null && activeNetwork.getType() == ConnectivityManager.TYPE_WIFI;
        } catch (Exception e) {
            isConnected = false;
            isAvailable = false;
            isWiFi = false;
        }

        final String text = "Network status\n\tConnected: " + isConnected + "\n\tAvailable: " + isAvailable + "\n\tWifi status: " + (isWiFi ? "ON" : "OFF");
        Log.r(text);
        return text;
    }

    public static OkHttpClient.Builder getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final X509TrustManager x509TrustManager = new X509TrustManager() {
                @Override
                public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                }

                @Override
                public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                }

                @Override
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            };

            final TrustManager[] trustAllCerts = new TrustManager[]{x509TrustManager};

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            return new OkHttpClient.Builder()
                    .sslSocketFactory(sslSocketFactory, x509TrustManager)
                    .hostnameVerifier(new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            return true;
                        }
                    });
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    static GenericError parseError(final ResponseBody errorBody) {
        try {
            return JSONUtils.toObject(errorBody.bytes(), GenericError.class);
        } catch (Exception e) {
            return JSONUtils.toObject("{}".getBytes(), GenericError.class);
        }
    }
}
