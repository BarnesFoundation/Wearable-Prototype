package org.barnesfoundation.androidwear.model;

import android.text.TextUtils;

import org.barnesfoundation.androidwear.utils.JSONUtils;

public class Item {

    public String id = "";
    public String regionId = "";
    public String imageUrl = "";
    public String name = "";
    public String description = "";
    public double regionMinimumDistance;

    public boolean isValid() {
        return !TextUtils.isEmpty(imageUrl) && !TextUtils.isEmpty(description);
    }

    @Override
    public String toString() {
        return JSONUtils.toString(this);
    }
}
