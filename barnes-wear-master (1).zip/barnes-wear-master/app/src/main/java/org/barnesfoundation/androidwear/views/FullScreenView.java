package org.barnesfoundation.androidwear.views;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.view.View;

public class FullScreenView extends View {

    public FullScreenView(Context context) {
        super(context);
    }

    public FullScreenView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public FullScreenView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = Resources.getSystem().getDisplayMetrics().widthPixels;
        int height = Resources.getSystem().getDisplayMetrics().heightPixels;
        setMeasuredDimension(width, height);
    }
}
