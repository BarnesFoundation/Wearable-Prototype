package org.barnesfoundation.androidwear.network;

import android.provider.Settings;

import org.barnesfoundation.androidwear.BuildConfig;
import org.barnesfoundation.androidwear.model.AppConfig;
import org.barnesfoundation.androidwear.model.AuthResult;
import org.barnesfoundation.androidwear.model.DeviceId;
import org.barnesfoundation.androidwear.model.GenericError;
import org.barnesfoundation.androidwear.model.Item;
import org.barnesfoundation.androidwear.model.SavedItem;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.barnesfoundation.androidwear.utils.ApplicationData;
import org.barnesfoundation.androidwear.utils.BuildConstants;
import org.barnesfoundation.androidwear.utils.JSONUtils;
import org.barnesfoundation.androidwear.utils.Log;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiService {

    private static final int REQUEST_RETRIES = 3;
    private static final ApiEndpoint HANDLER_API_SERVICE_NO_AUTH = createApiEndpoint(false);
    private static final ApiEndpoint HANDLER_API_SERVICE_WITH_AUTH = createApiEndpoint(true);

    private ApiService() {

    }

    private static ApiEndpoint createApiEndpoint(final boolean auth) {
        final OkHttpClient.Builder clientBuilder = NetworkUtils.getUnsafeOkHttpClient();
        if (BuildConfig.WRITE_LOGS) {
            clientBuilder.addInterceptor(new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY));
        }

        if (auth) {
            clientBuilder.addInterceptor(new Interceptor() {
                @Override
                public Response intercept(Chain chain) throws IOException {
                    Request original = chain.request();

                    Request authRequest = getAuthRequest(original);

                    if (getAuthResult() == null || !getAuthResult().isValid()) {
                        Log.e("Not logged in. Trying to login.");
                        authenticate();
                        authRequest = getAuthRequest(original);
                    }

                    Response response = chain.proceed(authRequest);

                    //if unauthorized, tries to authorize only once
                    if (response.code() == 401) {
                        Log.e("Reponse Code 401 trying to authenticate");
                        response.close();
                        authenticate();
                        authRequest = getAuthRequest(original);
                        response = chain.proceed(authRequest);
                    }

                    int retriesCount = 0;
                    while (response.code() != 401 && !response.isSuccessful() && retriesCount < REQUEST_RETRIES) {
                        response.close();
                        retriesCount++;
                        Log.e(String.format(Locale.getDefault(), "Request is not successful code: %d retrying: %d/%d", response.code(), retriesCount, REQUEST_RETRIES));
                        response = chain.proceed(authRequest);
                    }


                    return response;
                }
            });
        }

        return new Retrofit.Builder()
                .client(clientBuilder.build())
                .baseUrl(BuildConfig.SERVER_BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(JSONUtils.GSON))
                .build()
                .create(ApiEndpoint.class);
    }

    private static ApiEndpoint getEndpoint(final boolean authorization) {
        if (authorization) {
            return HANDLER_API_SERVICE_WITH_AUTH;
        }
        return HANDLER_API_SERVICE_NO_AUTH;
    }

    private static AuthResult getAuthResult() {
        final AuthResult authResult = MiscPref.getObject(MiscPref.ObjectKey.AUTH_CREDENTIALS, AuthResult.class);
        // returning an empty instance will prevent NullPointerExceptions
        return authResult == null ? new AuthResult() : authResult;
    }

    private static Request getAuthRequest(final Request original) {
        final AuthResult authResult = getAuthResult();
        final String authToken = authResult == null || !authResult.isValid() ? "" : authResult.getAuthHeader();
        Log.e("Authorization", authToken);
        return original.newBuilder()
                .header("Authorization", authToken)
                .method(original.method(), original.body())
                .build();
    }

    private static Call<AuthResult> getAuthCall() {
        return getEndpoint(false).login("password", BuildConstants.CLIENT_ID,
                BuildConstants.CLIENT_SECRET, BuildConstants.USER_NAME, BuildConstants.USER_SECRET);
    }

    private static AuthResult authenticate() {
        try {
            final AuthResult result = getAuthCall().execute().body();
            MiscPref.saveObject(MiscPref.ObjectKey.AUTH_CREDENTIALS, result);
            return result;
        } catch (IOException e) {
            Log.logException(e);
        }
        return null;
    }

    public static void authenticate(final ServiceCallback<AuthResult> callback) {
        getAuthCall().enqueue(new NetworkCallback<AuthResult>() {
            @Override
            public void success(AuthResult response, int code) {
                MiscPref.saveObject(MiscPref.ObjectKey.AUTH_CREDENTIALS, response);
                ServiceCallback.Call.onSuccess(callback, response);
            }
        });
    }

    public static void search(final String uuid, final ServiceCallback<List<Item>> callback) {
        getEndpoint(true).getItems(getAuthResult().getApexRestUrl("Item"), uuid)
                .enqueue(new NetworkCallback<List<Item>>() {
                    @Override
                    public void success(List<Item> response, int code) {
                        ServiceCallback.Call.onSuccess(callback, response);
                    }
                });
    }

    public static void getAppConfig(final ServiceCallback<AppConfig> callback) {
        getEndpoint(true).getConfig(getAuthResult().getApexRestUrl("AppConfig")).enqueue(new NetworkCallback<AppConfig>() {
            @Override
            public void success(AppConfig response, int code) {
                MiscPref.saveObject(MiscPref.ObjectKey.APP_CONFIG, response);
                ServiceCallback.Call.onSuccess(callback, response);
            }
        });
    }

    public static void getDeviceId(final ServiceCallback<DeviceId> callback) {
        final DeviceId savedDeviceId = MiscPref.getObject(MiscPref.ObjectKey.DEVICE_ID, DeviceId.class);
        if (savedDeviceId != null && savedDeviceId.isValid()) {
            ServiceCallback.Call.onSuccess(callback, savedDeviceId);
        } else {
            final String id = Settings.Secure.getString(ApplicationData.getAppContext().getContentResolver(), Settings.Secure.ANDROID_ID);
            final Map<String, String> map = new HashMap<>();
            map.put("localDeviceId", id);
            getEndpoint(true).updateDeviceId(getAuthResult().getApexRestUrl("Device"), map).enqueue(new NetworkCallback<DeviceId>() {
                @Override
                public void success(DeviceId response, int code) {
                    MiscPref.saveObject(MiscPref.ObjectKey.DEVICE_ID, response);
                    ServiceCallback.Call.onSuccess(callback, response);
                }
            });
        }
    }

    public static void saveForLater(final String itemId, final ServiceCallback<SavedItem> callback) {
        final DeviceId savedDeviceId = MiscPref.getObject(MiscPref.ObjectKey.DEVICE_ID, DeviceId.class);
        if (savedDeviceId != null && savedDeviceId.isValid()) {
            final Map<String, String> map = new HashMap<>();
            map.put("deviceId", savedDeviceId.remoteDeviceId);
            map.put("itemId", itemId);
            getEndpoint(true).saveForLater(getAuthResult().getApexRestUrl("SavedItem"), map).enqueue(new NetworkCallback<SavedItem>() {
                @Override
                public void success(SavedItem response, int code) {
                    ServiceCallback.Call.onSuccess(callback, response);
                }

                @Override
                public void error(GenericError error) {
                    ServiceCallback.Call.onError(callback, error);
                }
            });
        } else {
            ServiceCallback.Call.onError(callback, new GenericError());
        }
    }
}
