package org.barnesfoundation.androidwear.event;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.Region;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class BeaconsFoundEvent {
    public List<Beacon> collection;
    public Region region;

    public BeaconsFoundEvent(Collection<Beacon> collection, Region region) {
        this.collection = new ArrayList<>(collection);
        this.region = region;
    }

    public Beacon getFirst() {
        return collection.size() > 0 ? collection.get(0) : null;
    }
}
