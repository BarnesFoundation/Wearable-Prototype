package org.barnesfoundation.androidwear.fragments;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.view.View;

import org.barnesfoundation.androidwear.utils.Log;

public class PageLogsFragment extends ScreenSlidePageFragment {

    private static final long REFRESH_RATE = 5000;

    private static final int MAX_LOG_LENGTH = 7000;

    private Handler mRefreshHandler = new Handler();
    private final Runnable mRefreshRunnable = new Runnable() {
        @Override
        public void run() {
            updateText();
        }
    };

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        updateText();
    }

    @Override
    public void onDestroyView() {
        mRefreshHandler.removeCallbacksAndMessages(null);
        mRefreshHandler = null;
        super.onDestroyView();
    }

    private void updateText() {
        new AsyncTask<Void, Void, String>() {

            @Override
            protected String doInBackground(Void... params) {
                final String logs = Log.getReporterLogs();
                return logs.substring(Math.max(0, logs.length() - MAX_LOG_LENGTH));
            }

            @Override
            protected void onPostExecute(String s) {
                setText(s);
                if (isVisible() && mRefreshHandler != null) {
                    mRefreshHandler.postDelayed(mRefreshRunnable, REFRESH_RATE);
                }
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }
}
