package org.barnesfoundation.androidwear.beacons;

import org.altbeacon.beacon.Beacon;
import org.barnesfoundation.androidwear.event.BeaconsFoundEvent;
import org.barnesfoundation.androidwear.event.ItemDiscoveredEvent;
import org.barnesfoundation.androidwear.model.GenericError;
import org.barnesfoundation.androidwear.model.Item;
import org.barnesfoundation.androidwear.network.ApiService;
import org.barnesfoundation.androidwear.network.NetworkUtils;
import org.barnesfoundation.androidwear.network.ServiceCallback;
import org.barnesfoundation.androidwear.utils.ApplicationData;
import org.barnesfoundation.androidwear.utils.Log;
import org.barnesfoundation.androidwear.utils.NotificationUtils;

import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BeaconUtils {

    private static final Set<String> REGIONS_VISITED = new HashSet<>();
    private static final Set<Beacon> BEACONS_VISITED = new HashSet<>();

    private static final BeaconDetectionBehavior SIMPLE_DETECTION_BEHAVIOR = new BeaconSimpleDetection();
    private static final BeaconDetectionBehavior DOUBLE_DETECTION_BEHAVIOR = new BeaconDoubleDelayDetection();
    private static final BeaconDetectionBehavior MAJORITY_HIT_DETECTION_BEHAVIOR = new BeaconMajorityHitDetection();

    public static BeaconDetectionBehavior getDetectionBehavior() {
        return SIMPLE_DETECTION_BEHAVIOR;
//        return DOUBLE_DETECTION_BEHAVIOR;
//        return MAJORITY_HIT_DETECTION_BEHAVIOR;
    }

    public static long getScanPeriod() {
        return getDetectionBehavior().getScanPeriod();
    }

    public static long getScanBetweenPeriod() {
        return getDetectionBehavior().getScanBetweenPeriod();
    }

    public static void resetSession() {
        REGIONS_VISITED.clear();
        BEACONS_VISITED.clear();
        ApplicationData.getEventBus().removeStickyEvent(ItemDiscoveredEvent.class);
        ApplicationData.getEventBus().removeStickyEvent(BeaconsFoundEvent.class);
    }

    public static String getBeaconsList(final List<Beacon> list) {
        final DecimalFormat df = new DecimalFormat("#.00");
        final StringBuilder builder = new StringBuilder().append("Beacons found: ").append(list.size())
                .append("\nDetection mode: ").append(getDetectionBehavior().getDescription())
                .append("\nPeriod scan: ").append(getScanPeriod()).append(" between: ").append(getScanBetweenPeriod());
        for (Beacon curr : list) {
            builder.append("\n\t").append(getBeaconRepresentation(curr)).append(" - ").append(df.format(curr.getDistance())).append(" meters");
        }
        return builder.toString();
    }

    static String getBeaconRepresentation(final Beacon beacon) {
        if (beacon == null) {
            return "-";
        }
        return beacon.getId2().toString();
    }

    public static void beaconDetected(final Beacon beacon) {
        Log.r("Beacon detected: " + getBeaconRepresentation(beacon));
        getDetectionBehavior().newBeaconDetected(beacon);
    }

    public static void fetchItemForRegion(final String regionId) {
        ApiService.search(regionId, new ServiceCallback<List<Item>>() {
            @Override
            public void onSuccess(List<Item> result) {
                NotificationUtils.showNotification(result);
            }

            @Override
            public void onEror(GenericError error) {
            }
        });
    }

    static void fetchItem(final Beacon beacon) {
        NetworkUtils.getNewtorkStatusMessage();
        Log.r("Fetching content for beacon: " + getBeaconRepresentation(beacon));
        ApiService.search(beacon.getId2().toString(), new ServiceCallback<List<Item>>() {
            @Override
            public void onSuccess(List<Item> result) {
                getDetectionBehavior().itemsFetched(beacon, result);

//                for (Item currItem : result) {
//                    final boolean minimumDistance = beacon.getDistance() >= currItem.regionMinimumDistance;
//                    Log.r("Content fetched for beacon: " + getBeaconRepresentation(beacon)
//                            + "\ncurrent item is: " + currItem.id
//                            + "\nbeacon distance is: " + beacon.getDistance()
//                            + "\nregion min distance is: " + currItem.regionMinimumDistance);
//                    if (minimumDistance) {
//                        getDetectionBehavior().itemsFetched(beacon, result);
//                        break;
//                    }
//                }
            }

            @Override
            public void onEror(GenericError error) {
            }
        });
    }

    static void postItem(final List<Item> items, final Beacon beacon) {
        Log.r("Post new item" +
                "\n\tItems fetched: " + (items == null ? "empty" : items.size()) +
                "\n\tFor beacon: " + getBeaconRepresentation(beacon) +
                "\n\tRegion already visited? " + (items == null || items.size() == 0 ? "empty" : REGIONS_VISITED.contains(items.get(0).regionId)) +
                "\n\tBeacon already visited? " + BEACONS_VISITED.contains(beacon));
        if (items != null && items.size() > 0 && !REGIONS_VISITED.contains(items.get(0).regionId) && !BEACONS_VISITED.contains(beacon)) {
            REGIONS_VISITED.add(items.get(0).regionId);
            BEACONS_VISITED.add(beacon);
            NotificationUtils.showNotification(items);
        }
    }
}
