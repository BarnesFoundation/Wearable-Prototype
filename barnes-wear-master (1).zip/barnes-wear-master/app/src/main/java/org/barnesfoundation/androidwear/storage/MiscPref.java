package org.barnesfoundation.androidwear.storage;

import org.barnesfoundation.androidwear.utils.JSONUtils;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class MiscPref {

    private static final String PREF_FILE = "misc_pref";

    private static final Map<ObjectKey, Object> OBJECTS_MAP = new HashMap<>();

    public static void deleteObject(final ObjectKey key) {
        PrefUtils.removeValue(PREF_FILE, key.getKey());
        OBJECTS_MAP.remove(key);
    }

    public static void saveObject(final ObjectKey key, final Object object) {
        final String json = JSONUtils.toString(object);
        PrefUtils.setStringValue(PREF_FILE, key.getKey(), json);
        OBJECTS_MAP.put(key, object);
    }

    public static <T> T getObject(final ObjectKey key, final Type type) {
        T object = (T) OBJECTS_MAP.get(key);
        if (object == null) {
            final String json = PrefUtils.getStringValue(PREF_FILE, key.getKey());
            object = JSONUtils.toObject(json, type);
            if (object != null) {
                OBJECTS_MAP.put(key, object);
            }
        }
        return object;
    }


    public static int getIntValue(final ObjectKey key) {
        return PrefUtils.getIntValue(PREF_FILE, key.getKey());
    }

    public static float getFloatValue(final ObjectKey key) {
        return PrefUtils.getFloatValue(PREF_FILE, key.getKey());
    }

    public static void setIntValue(final ObjectKey key, final int value) {
        PrefUtils.setIntValue(PREF_FILE, key.getKey(), value);
    }

    public static String getStringValue(final ObjectKey key) {
        return PrefUtils.getStringValue(PREF_FILE, key.getKey());
    }

    public static void setStringValue(final ObjectKey key, final String value) {
        PrefUtils.setStringValue(PREF_FILE, key.getKey(), value);
    }

    public static long getLongValue(final ObjectKey key) {
        return PrefUtils.getLongValue(PREF_FILE, key.getKey());
    }

    public static void setLongValue(final ObjectKey key, final long value) {
        PrefUtils.setLongValue(PREF_FILE, key.getKey(), value);
    }

    public static boolean getBooleanValue(final ObjectKey key) {
        return PrefUtils.getBooleanValue(PREF_FILE, key.getKey());
    }

    public static void setBooleanValue(final ObjectKey key, final boolean value) {
        PrefUtils.setBooleanValue(PREF_FILE, key.getKey(), value);
    }

    public static void setFloatValue(final ObjectKey key, final float value) {
        PrefUtils.setFloatValue(PREF_FILE, key.getKey(), value);
    }


    public enum ObjectKey {
        AUTH_CREDENTIALS, SAVE_FOR_LATER_DISABLED, BEACON_MONITORING_DISABLED,
        DEVICE_ID, APP_CONFIG, SETTINGS_ENABLED, AUTO_RESUME_APP_DISABLED, SHOW_MULTIPLE_ITEMS_DISABLED,
        SAVED_ITEM_CONFIRMATION_ALREADY_SHOWN, SAVED_ITEMS_MAP;

        public String getKey() {
            return name() + "_KEY";
        }
    }

}
