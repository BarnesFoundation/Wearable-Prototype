package org.barnesfoundation.androidwear.event;

import org.barnesfoundation.androidwear.model.Item;

import java.util.List;

public class ItemDiscoveredEvent {
    public List<Item> items;

    public ItemDiscoveredEvent(List<Item> items) {
        this.items = items;
    }
}
