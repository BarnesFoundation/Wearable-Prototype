package org.barnesfoundation.androidwear.fragments;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;
import android.support.wearable.view.WearableRecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.FutureTarget;

import org.barnesfoundation.androidwear.R;
import org.barnesfoundation.androidwear.adapter.ItemAdapter;
import org.barnesfoundation.androidwear.event.ItemDiscoveredEvent;
import org.barnesfoundation.androidwear.event.SettingsEnabledEvent;
import org.barnesfoundation.androidwear.model.GenericError;
import org.barnesfoundation.androidwear.model.Item;
import org.barnesfoundation.androidwear.model.SaveForLater;
import org.barnesfoundation.androidwear.model.SavedItem;
import org.barnesfoundation.androidwear.network.ApiService;
import org.barnesfoundation.androidwear.network.ServiceCallback;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.barnesfoundation.androidwear.utils.AlertUtils;
import org.barnesfoundation.androidwear.utils.ApplicationData;
import org.barnesfoundation.androidwear.views.UnlockView;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.util.List;
import java.util.Random;

import static org.barnesfoundation.androidwear.storage.MiscPref.ObjectKey.SAVED_ITEM_CONFIRMATION_ALREADY_SHOWN;

public class PageItemMainFragment extends ScreenSlidePageFragment implements UnlockView.OnUnlockedListener {

    private UnlockView mUnlockView;
    private WearableRecyclerView mWearableRecyclerView;
    private ItemAdapter mAdapter;
    private final ItemAdapter.OnItemClickedListener onItemClickedListener = new ItemAdapter.OnItemClickedListener() {
        @Override
        public void saveForLater(Item item) {
            saveItemForLater(item);
        }
    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_item, container, false);
        mWearableRecyclerView = (WearableRecyclerView) rootView.findViewById(R.id.wearable_recyclerview);
        mUnlockView = (UnlockView) rootView.findViewById(R.id.fragment_item_unlock_view);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mUnlockView.setUnlockedListener(this);
        final LinearLayoutManager horizontalLayoutManagaer
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        mWearableRecyclerView.setLayoutManager(horizontalLayoutManagaer);
        SnapHelper snapHelper = new LinearSnapHelper();
        snapHelper.attachToRecyclerView(mWearableRecyclerView);
        mAdapter = new ItemAdapter(onItemClickedListener);
        mWearableRecyclerView.setAdapter(mAdapter);

        mWearableRecyclerView.addOnChildAttachStateChangeListener(new RecyclerView.OnChildAttachStateChangeListener() {
            @Override
            public void onChildViewAttachedToWindow(View view) {
                mAdapter.viewAttached(view);
            }

            @Override
            public void onChildViewDetachedFromWindow(View view) {
            }
        });
    }

    @Override
    public void unlocked() {
        if (!MiscPref.getBooleanValue(MiscPref.ObjectKey.SETTINGS_ENABLED)) {
            ApplicationData.getEventBus().post(new SettingsEnabledEvent(true));
        }
    }

    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    public void itemDiscoveredEvent(final ItemDiscoveredEvent event) {
        setupItems(event.items, 0);
    }

    private void setupItems(final List<Item> items, final int attempts) {
        if (items != null) {
            if (mUnlockView != null && mAdapter != null) {
                downloadAllImages(items);
            } else if (attempts < 2) {
                //try again for a couple times, this is to wait until the view is created
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setupItems(items, attempts + 1);
                    }
                }, 1000);
            }
        }
    }

    private void downloadAllImages(final List<Item> items) {
        mUnlockView.post(new Runnable() {
            @Override
            public void run() {
                final float width = mUnlockView.getWidth();
                final float height = mUnlockView.getHeight();
                final boolean showMultipleItems = !MiscPref.getBooleanValue(MiscPref.ObjectKey.SHOW_MULTIPLE_ITEMS_DISABLED);

                final int firstIndex = showMultipleItems ? 0 : new Random().nextInt(items.size());
                final boolean fetchNext = showMultipleItems;

                //            downloadImages(items, 0, true);
                downloadImages(items, width, height, firstIndex, fetchNext);
            }
        });
    }

    private void downloadImages(final List<Item> items, final float width, final float height, final int currentPosition, final boolean fetchNext) {
        if (items != null && currentPosition < items.size()) {
            final Item currentItem = items.get(currentPosition);
            new AsyncTask<Object, Object, File>() {

                @Override
                protected File doInBackground(Object... params) {
                    FutureTarget<File> futureTarget = Glide.with(PageItemMainFragment.this)
                            .load(currentItem.imageUrl)
                            .downloadOnly((int) width, (int) height);

                    try {
                        return futureTarget.get();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return null;
                }

                @Override
                protected void onPostExecute(File file) {
                    if (file != null && file.exists()) {
                        mAdapter.addItem(currentItem);
                    }
                    if (fetchNext) {
                        downloadImages(items, width, height, currentPosition + 1, fetchNext);
                    }
                }
            }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        }
    }

    private void saveItemForLater(final Item item) {
        if (item != null && item.isValid()) {
//            mAdapter.setSaveForLaterState(item, R.string.saving_item);
            mAdapter.setSaveForLaterState(item, SaveForLater.State.SAVING);
            ApiService.saveForLater(item.id, new ServiceCallback<SavedItem>() {
                @Override
                public void onSuccess(SavedItem result) {
                    if (result != null && result.isValid()) {
                        if (!MiscPref.getBooleanValue(SAVED_ITEM_CONFIRMATION_ALREADY_SHOWN)) {
                            AlertUtils.showCustomNeutralDialog(getActivity(), getString(R.string.item_saved_title), getString(R.string.item_saved_message));
                            MiscPref.setBooleanValue(SAVED_ITEM_CONFIRMATION_ALREADY_SHOWN, true);
                        } else {
                            AlertUtils.showConfirmationOverlay(getActivity(), getString(R.string.item_saved));
                        }
//                        mAdapter.setSaveForLaterState(item, R.string.item_saved);
                        mAdapter.setSaveForLaterState(item, SaveForLater.State.SAVED);
                    } else {
//                        mAdapter.setSaveForLaterState(item, R.string.save_for_later);
                        mAdapter.setSaveForLaterState(item, SaveForLater.State.READY_TO_SAVE);
                    }
                }

                @Override
                public void onEror(GenericError error) {
//                    mAdapter.setSaveForLaterState(item, R.string.save_for_later);
                    mAdapter.setSaveForLaterState(item, SaveForLater.State.READY_TO_SAVE);
                }
            });
        }
    }
}
