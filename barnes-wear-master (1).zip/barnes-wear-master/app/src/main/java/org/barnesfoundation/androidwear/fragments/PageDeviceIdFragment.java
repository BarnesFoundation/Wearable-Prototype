package org.barnesfoundation.androidwear.fragments;

import org.barnesfoundation.androidwear.BuildConfig;
import org.barnesfoundation.androidwear.model.AppConfig;
import org.barnesfoundation.androidwear.model.DeviceId;
import org.barnesfoundation.androidwear.model.GenericError;
import org.barnesfoundation.androidwear.network.ApiService;
import org.barnesfoundation.androidwear.network.ServiceCallback;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.barnesfoundation.androidwear.utils.JSONUtils;

public class PageDeviceIdFragment extends ScreenSlidePageFragment {
    @Override
    public void onResume() {
        super.onResume();
        updateText();
    }

    @Override
    public void setMenuVisibility(boolean menuVisible) {
        super.setMenuVisibility(menuVisible);
        if (menuVisible) {
            updateText();
        }
    }

    private void updateText() {
        ApiService.getDeviceId(new ServiceCallback<DeviceId>() {
            @Override
            public void onSuccess(DeviceId result) {
                final AppConfig appConfig = MiscPref.getObject(MiscPref.ObjectKey.APP_CONFIG, AppConfig.class);
                final StringBuilder builder = new StringBuilder()
                        .append("Salesforce id: ").append(result.remoteDeviceId)
                        .append("\n\nLocal id: ").append(result.localDeviceId)
                        .append("\n\nApp version: ").append(BuildConfig.VERSION_NAME).append(" / ").append(BuildConfig.VERSION_CODE)
                        .append("\n\nBuild type: ").append(BuildConfig.BUILD_TYPE).append(" / ").append(BuildConfig.FLAVOR)
                        .append("\n\nApp config: ").append(JSONUtils.toString(appConfig));
                setText(builder.toString());
            }

            @Override
            public void onEror(GenericError error) {
                setText("Could not contact the server");
            }
        });
    }
}
