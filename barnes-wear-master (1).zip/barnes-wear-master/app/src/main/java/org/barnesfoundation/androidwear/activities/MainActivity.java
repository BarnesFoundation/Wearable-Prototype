package org.barnesfoundation.androidwear.activities;

import android.Manifest;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.support.v13.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.WindowManager;

import org.barnesfoundation.androidwear.R;
import org.barnesfoundation.androidwear.event.SettingsEnabledEvent;
import org.barnesfoundation.androidwear.fragments.PageBeaconsFragment;
import org.barnesfoundation.androidwear.fragments.PageDeviceIdFragment;
import org.barnesfoundation.androidwear.fragments.PageItemMainFragment;
import org.barnesfoundation.androidwear.fragments.PageLogsFragment;
import org.barnesfoundation.androidwear.fragments.PageNetworkStatusFragment;
import org.barnesfoundation.androidwear.fragments.PageSettingsFragment;
import org.barnesfoundation.androidwear.network.ApiService;
import org.barnesfoundation.androidwear.network.NetworkUtils;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.barnesfoundation.androidwear.utils.AlertUtils;
import org.barnesfoundation.androidwear.utils.PermissionUtils;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;


public class MainActivity extends BaseActivity {

    private static final int NUM_PAGES = 6;

    private ViewPager mPager;
    private PagerAdapter mPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setAmbientEnabled();

        mPager = (ViewPager) findViewById(R.id.view_pager);
        mPagerAdapter = new ScreenSlidePagerAdapter(getFragmentManager());
        mPager.setAdapter(mPagerAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ApiService.getAppConfig(null);
        if (!PermissionUtils.hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            PermissionUtils.requestPermissions(this, Manifest.permission.ACCESS_FINE_LOCATION);
        }

        if (!NetworkUtils.getConnectivityStatus()) {
            NetworkUtils.reconnectToFirstNetwork();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onSettingsEnabledEvent(final SettingsEnabledEvent event) {
        MiscPref.setBooleanValue(MiscPref.ObjectKey.SETTINGS_ENABLED, event.enabled);
        AlertUtils.showToast(event.enabled ? R.string.admin_enabled : R.string.admin_disabled);
        mPagerAdapter.notifyDataSetChanged();
    }

    private class ScreenSlidePagerAdapter extends FragmentStatePagerAdapter {
        public ScreenSlidePagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public int getItemPosition(Object object) {
            return PagerAdapter.POSITION_NONE;
        }

        @Override
        public Fragment getItem(int position) {
            if (position == 0) {
                return new PageItemMainFragment();
            } else if (position == 1) {
                return new PageDeviceIdFragment();
            } else if (position == 2) {
                return new PageBeaconsFragment();
            } else if (position == 3) {
                return new PageNetworkStatusFragment();
            } else if (position == 4) {
                return new PageLogsFragment();
            } else {
                return new PageSettingsFragment();
            }
        }

        @Override
        public int getCount() {
            return MiscPref.getBooleanValue(MiscPref.ObjectKey.SETTINGS_ENABLED) ? NUM_PAGES : 1;
        }
    }

}
