package org.barnesfoundation.androidwear.model;

import java.util.HashMap;
import java.util.Map;

public class SaveForLater {

    public Map<String, State> map = new HashMap<>();

    public State getState(final Item item) {
        final State state = map.get(item.id);
        if (state == null) {
            return State.READY_TO_SAVE;
        }
        return state;
    }

    public void setState(final Item item, final State state) {
        map.put(item.id, state);
    }

    public enum State {
        READY_TO_SAVE, SAVING, SAVED
    }

}
