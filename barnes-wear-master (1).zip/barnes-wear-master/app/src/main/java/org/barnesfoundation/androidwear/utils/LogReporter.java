package org.barnesfoundation.androidwear.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.SystemClock;
import android.util.Pair;

import org.barnesfoundation.androidwear.BuildConfig;
import org.barnesfoundation.androidwear.model.DeviceId;
import org.barnesfoundation.androidwear.network.LogUploadService;
import org.barnesfoundation.androidwear.storage.MiscPref;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LogReporter {

    public static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault());
    private static final String FILES_DIR = "reportLogFiles";
    //private static final long TIME_TO_FLUSH = TimeUnit.MINUTES.toMillis(5);
    private static final int SIZE_TO_FLUSH = 1024 * 500;

    //    private final AtomicBoolean syncronizedAtomicBoolean = new AtomicBoolean();
    private final List<Pair<Long, String>> reportList = Collections.synchronizedList(new ArrayList<Pair<Long, String>>());

    private long lastTimeFlushed = SystemClock.elapsedRealtime();

    public void appendLine(final String message) {
        new Thread() {
            @Override
            public void run() {
                synchronized (reportList) {
                    reportList.add(new Pair<>(System.currentTimeMillis(), message));
                }
                if (BuildConfig.UPLOAD_LOGS) {
                    flushBuffer(false);
                }
            }
        }.start();
    }

    public void flushBuffer(final boolean forceFlush) {
        new Thread() {
            @Override
            public void run() {
                final StringBuilder builder = buildLog(true, true);
                synchronized (reportList) {
                    //final boolean timeCondition = (SystemClock.elapsedRealtime() - lastTimeFlushed) >= TIME_TO_FLUSH;
                    final boolean timeCondition = true;
                    final int logSize = builder.length();
                    if (forceFlush || logSize >= SIZE_TO_FLUSH) {
                        lastTimeFlushed = SystemClock.elapsedRealtime();
                        reportList.clear();
                        flushData(builder);
                    }
                }
            }
        }.start();
    }

    public StringBuilder buildLog(final boolean includeHeader, final boolean inckudeFooter) {
        final StringBuilder builder = new StringBuilder();
        final List<Pair<Long, String>> listCopy = new ArrayList<>();
        synchronized (reportList) {
            listCopy.addAll(reportList);
        }

        if (includeHeader) {
            final Context context = ApplicationData.getAppContext();
            PackageInfo pInfo = null;
            try {
                pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            } catch (Exception e) {
                e.printStackTrace();
            }

            final DeviceId savedDeviceId = MiscPref.getObject(MiscPref.ObjectKey.DEVICE_ID, DeviceId.class);

            builder.append("Flushing ").append(listCopy.size()).append(" lines of data")
                    .append(" on ").append(SDF.format(new Date()))
                    .append("\nVersion name: ").append(pInfo == null ? " - " : pInfo.versionName).append(", code: ").append(pInfo == null ? " - " : pInfo.versionCode)
                    .append("\nBuild type: ").append(BuildConfig.BUILD_TYPE).append(", flavor: ").append(BuildConfig.FLAVOR)
                    .append("\nDevice ids remote: ").append(savedDeviceId.remoteDeviceId).append(", local id: ").append(savedDeviceId.localDeviceId)
                    .append("\n\n");
        }

        for (Pair<Long, String> current : listCopy) {
            builder.append(SDF.format(new Date(current.first)))
                    .append(" ")
                    .append(current.second)
                    .append("\n\n");
        }

        if (inckudeFooter) {
            builder.append(" EOF ========================================== ");
        }

        return builder;
    }

    private void saveLogToFile(final File parentDir, final StringBuilder builder) {
        final File outFile = new File(parentDir, SDF.format(new Date()) + ".txt");
        final FileOutputStream outputStream;
        try {
            outputStream = new FileOutputStream(outFile);
            outputStream.write(builder.toString().getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void flushData(final StringBuilder builder) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final Context context = ApplicationData.getAppContext();
                final File parentDir = context.getDir(FILES_DIR, Context.MODE_PRIVATE);
                saveLogToFile(parentDir, builder);
                LogUploadService.uploadAllLogs(parentDir);
            }
        }).start();
    }
}
