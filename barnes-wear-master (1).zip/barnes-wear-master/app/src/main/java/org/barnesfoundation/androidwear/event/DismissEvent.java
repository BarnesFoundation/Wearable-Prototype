package org.barnesfoundation.androidwear.event;

/**
 * Created by tales on 10/24/2016.
 */

public class DismissEvent {
}
