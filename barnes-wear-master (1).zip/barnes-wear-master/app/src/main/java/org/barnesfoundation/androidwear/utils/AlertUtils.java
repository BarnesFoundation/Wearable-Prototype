package org.barnesfoundation.androidwear.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.StyleRes;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DialogTitle;
import android.support.wearable.view.AcceptDenyDialog;
import android.support.wearable.view.AcceptDenyDialogFragment;
import android.support.wearable.view.ConfirmationOverlay;
import android.text.TextUtils;
import android.widget.Toast;

import org.barnesfoundation.androidwear.R;
import org.barnesfoundation.androidwear.views.CustomNeutralDialog;

public class AlertUtils {
    public static void showToast(final int textId) {
        showToast(textId, Toast.LENGTH_SHORT);
    }

    public static void showToast(final int textId, final int length) {
        final Context context = ApplicationData.getAppContext();
        if (context != null) {
            showToast(context.getString(textId), length);
        }
    }

    public static void showToast(final String text) {
        showToast(text, Toast.LENGTH_SHORT);
    }

    public static void showToast(final String text, final int length) {
        final Context context = ApplicationData.getAppContext();
        if (context != null) {
            Toast toast = Toast.makeText(context, text, length);
            toast.show();
        }
    }

    public static void showCustomNeutralDialog(final Activity activity,
                                            final String title,
                                            final String message) {
        final CustomNeutralDialog dialog = new CustomNeutralDialog(activity, R.style.FramelessDialog);
        dialog.setMessage(message);
        dialog.setTitle(title);
        dialog.show();
    }

    public static void showNeutralDialog(final Activity activity,
                                            final String title,
                                            final String message) {
        showWearDialog(activity, title, message, null, true, false, false, null);

    }

    public static void showAcceptDenyDialog(final Activity activity,
                                            final String title,
                                            final String message,
                                            final String confirmationMessage,
                                            final DialogInterface.OnClickListener listener) {

        showWearDialog(activity, title, message, confirmationMessage, true, true, false, listener);
    }

    public static void showConfirmationOverlay(final Activity activity, final String confirmationMessage){
        new ConfirmationOverlay()
                .setType(ConfirmationOverlay.SUCCESS_ANIMATION)
                .setMessage(confirmationMessage)
                .showOn(activity);
    }

    public static void showWearDialog(final Activity activity,
                                            final String title,
                                            final String message,
                                            final String confirmationMessage,
                                            final boolean showPositiveButton,
                                            final boolean showNegativeButton,
                                            final boolean cancelable,
                                            final DialogInterface.OnClickListener listener) {
        final DialogInterface.OnClickListener placeHolderListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == DialogInterface.BUTTON_POSITIVE && !TextUtils.isEmpty(confirmationMessage)){
                    showConfirmationOverlay(activity, confirmationMessage);
                }
                if (listener != null){
                    listener.onClick(dialog, which);
                }
            }
        };

        final AcceptDenyDialog acceptDenyDialog = new AcceptDenyDialog(activity, android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen);
        if (!TextUtils.isEmpty(message)) {
            acceptDenyDialog.setMessage(message);
        }
        if (!TextUtils.isEmpty(title)) {
            acceptDenyDialog.setTitle(title);
        }

        if (showNegativeButton){
            acceptDenyDialog.setNegativeButton(placeHolderListener);
        }

        if (showPositiveButton){
            acceptDenyDialog.setPositiveButton(placeHolderListener);
        }
        acceptDenyDialog.setCancelable(cancelable);
        acceptDenyDialog.show();
    }
}
