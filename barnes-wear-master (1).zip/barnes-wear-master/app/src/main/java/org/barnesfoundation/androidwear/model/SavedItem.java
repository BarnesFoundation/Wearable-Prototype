package org.barnesfoundation.androidwear.model;

import android.text.TextUtils;

public class SavedItem {
    public String userId = "";
    public String itemId = "";

    public boolean isValid() {
        return !TextUtils.isEmpty(userId) && !TextUtils.isEmpty(itemId);
    }
}
