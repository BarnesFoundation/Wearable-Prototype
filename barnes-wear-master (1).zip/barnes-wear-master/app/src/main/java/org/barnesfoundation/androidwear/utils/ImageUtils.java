package org.barnesfoundation.androidwear.utils;

import android.widget.ImageView;

import com.bumptech.glide.Glide;

import org.barnesfoundation.androidwear.R;


public class ImageUtils {

    public static void loadImage(final String url, final ImageView imageView) {
        try {
            Glide.with(imageView.getContext()).load(url).placeholder(R.drawable.placeholder).centerCrop().dontAnimate().into(imageView);
        } catch (Exception e) {
            Log.e(e.getMessage());
        }
    }
}
