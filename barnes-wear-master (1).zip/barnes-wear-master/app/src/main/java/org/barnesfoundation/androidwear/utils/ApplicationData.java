package org.barnesfoundation.androidwear.utils;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.RemoteException;
import android.support.multidex.MultiDex;

import com.crashlytics.android.Crashlytics;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconConsumer;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.Identifier;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;
import org.barnesfoundation.androidwear.BuildConfig;
import org.barnesfoundation.androidwear.beacons.BeaconUtils;
import org.barnesfoundation.androidwear.event.BeaconsFoundEvent;
import org.barnesfoundation.androidwear.kiosk.KioskUtils;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import io.fabric.sdk.android.Fabric;

public class ApplicationData extends Application implements BeaconConsumer {

    public static final String BEACONS_UUID = "D0D3FA86-CA76-45EC-9BD9-6AF4B4B5F017";
    private static final String RANGING_ID = "org.barnesfoundation.androidwear.BeaconRanging";

    private static final long ACTIVITY_MONITOR_PERIOD = TimeUnit.SECONDS.toMillis(10);


    private static Context sContext;
    private static EventBus sEventBus = EventBus.getDefault();
    private final Handler mActivityMonitorHandler = new Handler();
    private final Runnable mActivityMonitorRunnable = new Runnable() {
        @Override
        public void run() {
            KioskUtils.checkAndRestartMainActivity();
            scheduleActivityMonitor();
        }
    };
    private BeaconManager mBeaconManager;

    public static Context getAppContext() {
        return sContext;
    }

    private void setAppContext(final Context context) {
        sContext = context;
    }

    public static EventBus getEventBus() {
        return sEventBus;
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        setAppContext(this);

        if (BuildConfig.REPORT_CRASHES) {
            Fabric.with(this, new Crashlytics());
        }

        setupBeaconManager();
        KioskUtils.setupAlarm();
        scheduleActivityMonitor();
    }

    private void scheduleActivityMonitor() {
        mActivityMonitorHandler.postDelayed(mActivityMonitorRunnable, ACTIVITY_MONITOR_PERIOD);
    }

    private void setupBeaconManager() {
        mBeaconManager = BeaconManager.getInstanceForApplication(this);
        mBeaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout("m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24"));
        mBeaconManager.addRangeNotifier(new RangeNotifier() {
            @Override
            public void didRangeBeaconsInRegion(Collection<Beacon> collection, Region region) {
                if (collection.size() > 0) {
                    final List<Beacon> beaconList = new ArrayList<>(collection);
                    Collections.sort(beaconList, new Comparator<Beacon>() {
                        @Override
                        public int compare(Beacon o1, Beacon o2) {
                            if (o1.getDistance() < o2.getDistance()) {
                                return -1;
                            }
                            if (o1.getDistance() > o2.getDistance()) {
                                return 1;
                            }
                            return 0;
                        }
                    });

                    Log.r(BeaconUtils.getBeaconsList(beaconList));

                    ApplicationData.getEventBus().post(new BeaconsFoundEvent(beaconList, region));
                    BeaconUtils.beaconDetected(beaconList.get(0));
                }
            }
        });
        mBeaconManager.setBackgroundScanPeriod(BeaconUtils.getScanPeriod());
        mBeaconManager.setForegroundScanPeriod(BeaconUtils.getScanPeriod());
        mBeaconManager.setBackgroundBetweenScanPeriod(BeaconUtils.getScanBetweenPeriod());
        mBeaconManager.setForegroundBetweenScanPeriod(BeaconUtils.getScanBetweenPeriod());
        mBeaconManager.bind(this);
    }

    public void startRanging(final String beaconsId) {
        final Region region = new Region(RANGING_ID, Identifier.parse(beaconsId), null, null);
        try {
            mBeaconManager.startRangingBeaconsInRegion(region);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public void stopRanging(final String beaconsId) {
        final Region region = new Region(RANGING_ID, Identifier.parse(beaconsId), null, null);
        try {
            mBeaconManager.stopRangingBeaconsInRegion(region);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBeaconServiceConnect() {
        if (!MiscPref.getBooleanValue(MiscPref.ObjectKey.BEACON_MONITORING_DISABLED)) {
            startRanging(BEACONS_UUID);
        }
    }
}