package org.barnesfoundation.androidwear.network;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Url;

public interface LogUploadEndpoint {

    String LOG_FILE_FIELD_NAME = "_1_file";
    String DESCRIPTION_FIELD_NAME = "_0_description";

    @Multipart
    @POST
    Call<ResponseBody> uploadLog(@Url String url,
                                 @Part(DESCRIPTION_FIELD_NAME) RequestBody description,
                                 @Part MultipartBody.Part file);
}
