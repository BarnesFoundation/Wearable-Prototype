package org.barnesfoundation.androidwear.utils;

import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class JSONUtils {

    public static final Gson GSON = new GsonBuilder()
            .excludeFieldsWithModifiers(Modifier.FINAL, Modifier.TRANSIENT, Modifier.STATIC)
            .registerTypeAdapter(Date.class, new GSONSerializers.DateSerializer())
            .registerTypeAdapter(Date.class, new GSONSerializers.DateDeserializer())
            .create();

    private static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ";
    private static final boolean PRINT_EXCEPTIONS = false;

    public static JSONArray parseJSONArray(byte[] response) {
        try {
            return new JSONArray(new String(response));
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return new JSONArray();
        }
    }

    public static JSONArray parseJSONArray(String json) {
        try {
            return new JSONArray(json);
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return new JSONArray();
        }
    }

    public static JSONObject parseJSONObject(byte[] response) {
        try {
            return new JSONObject(new String(response));
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return new JSONObject();
        }
    }

    public static JSONObject parseJSONObject(String json) {
        try {
            return new JSONObject(json);
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return new JSONObject();
        }
    }

    public static JSONArray getJSONArray(JSONObject jobj, String key) {
        try {
            return jobj.getJSONArray(key);
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return new JSONArray();
        }
    }

    public static int getInt(JSONObject jobj, String key, int defaultValue) {
        try {
            return jobj.getInt(key);
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return defaultValue;
        }
    }

    public static boolean getBoolean(JSONObject jobj, String key,
                                     boolean defaultValue) {
        try {
            return jobj.getBoolean(key);
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return defaultValue;
        }
    }

    public static long getLong(JSONObject jobj, String key, long defaultValue) {
        try {
            return jobj.getLong(key);
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return defaultValue;
        }
    }

    public static double getDouble(JSONObject jobj, String key,
                                   double defaultValue) {
        try {
            return jobj.getDouble(key);
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return defaultValue;
        }
    }

    public static String getString(JSONObject jobj, String key,
                                   String defaultValue) {
        try {
            jobj.getJSONArray(key);
            return defaultValue;
        } catch (Exception e) {
            try {
                String str = jobj.getString(key);
                if (str.equalsIgnoreCase("null"))
                    return defaultValue;
                return str;
            } catch (Exception e2) {
                if (PRINT_EXCEPTIONS)
                    e2.printStackTrace();
                return defaultValue;
            }
        }
    }

    public static List<String> getStringArray(JSONObject jobj, String key) {
        List<String> list = new ArrayList<>();
        try {
            JSONArray jarr = jobj.getJSONArray(key);
            for (int i = 0; i < jarr.length(); i++)
                list.add(jarr.getString(i));

        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
        }
        return list;
    }

    public static List<String> getErrorMessages(JSONObject jobj) {
        List<String> list = new ArrayList<>();
        try {
            JSONArray keys = jobj.names();
            for (int i = 0; i < keys.length(); i++) {
                String curr = keys.getString(i);
                list.addAll(getStringArray(jobj, curr));
            }
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
        }
        return list;
    }

    public static Date getDate(JSONObject jobj, String key) {
        return getDate(jobj, key, DEFAULT_DATE_FORMAT);
    }

    public static Date getDate(JSONObject jobj, String key, String format) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.ENGLISH);
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            return sdf.parse(jobj.getString(key));
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return new Date(0L);
        }
    }

    public static int[] getIntArray(JSONObject jobj, String key) {
        try {
            JSONArray jarr = jobj.getJSONArray(key);
            int[] intArr = new int[jarr.length()];
            for (int i = 0; i < jarr.length(); i++)
                intArr[i] = jarr.getInt(i);
            return intArr;
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return new int[0];
        }
    }

    public static JSONObject getJSONObject(JSONObject jobj, String key) {
        try {
            return jobj.getJSONObject(key);
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return new JSONObject();
        }
    }

    public static Object getObject(JSONObject jobj, String key) {
        try {
            return jobj.get(key);
        } catch (Exception e) {
            if (PRINT_EXCEPTIONS)
                e.printStackTrace();
            return new JSONObject();
        }
    }

    public static String toString(final Object object) {
        return GSON.toJson(object);
    }

    public static <T> T toObject(byte[] responseBody, Class<T> classOfT) {
        return toObject(responseBody, "", classOfT);
    }

    public static <T> T toObject(byte[] responseBody, Type typeOfT) {
        return toObject(responseBody, "", typeOfT);
    }

    public static String toObject(byte[] responseBody, String key) {
        final JSONObject jsonObject = JSONUtils.parseJSONObject(responseBody);
        if (TextUtils.isEmpty(key)) {
            return jsonObject.toString();
        } else {
            return JSONUtils.getObject(jsonObject, key).toString();
        }
    }

    public static <T> T toObject(byte[] responseBody, String key, Type typeOfT) {
        return toObject(toObject(responseBody, key), typeOfT);
    }

    public static <T> T toObject(byte[] responseBody, String key, Class<T> classOfT) {
        return toObject(toObject(responseBody, key), classOfT);
    }

    public static <T> T toObject(final String objStr, final Class<T> classOfT) {
        final String jsonStr = TextUtils.isEmpty(objStr) ? "{}" : objStr;
        final JsonElement jsonElement = GSON.fromJson(jsonStr, JsonElement.class);
        return GSON.fromJson(jsonElement, classOfT);
    }

    public static <T> T toObject(final String objStr, final Type type) {
        final String jsonStr = TextUtils.isEmpty(objStr) ? "{}" : objStr;
        final JsonElement jsonElement = GSON.fromJson(jsonStr, JsonElement.class);
        return GSON.fromJson(jsonElement, type);
    }
}
