package org.barnesfoundation.androidwear.activities;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.wearable.activity.WearableActivity;

import org.barnesfoundation.androidwear.utils.ApplicationData;
import org.barnesfoundation.androidwear.utils.PermissionUtils;
import org.greenrobot.eventbus.Subscribe;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public class BaseActivity extends WearableActivity implements PermissionUtils.Permissionable {

    private static final Set<Class> RUNNING_SET = new HashSet<>();

    private final int PERMISSIONS_REQUEST_CODE = PermissionUtils.generateNextRequestCode();

    public static boolean isVisible(final Class className) {
        return !RUNNING_SET.contains(className);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ApplicationData.getEventBus().register(this);
    }

    @Override
    protected void onDestroy() {
        ApplicationData.getEventBus().unregister(this);
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        RUNNING_SET.add(getClass());
        super.onStop();
    }

    @Override
    protected void onStart() {
        super.onStart();
        RUNNING_SET.remove(getClass());
    }

    @Subscribe
    public void anyEvent(AtomicBoolean value) {
        //empty event just to avoid error
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        PermissionUtils.processPermissionsResult(this, requestCode, permissions, grantResults);
    }

    @Override
    public int getRequestCode() {
        return PERMISSIONS_REQUEST_CODE;
    }

    @Override
    public void permissionsGranted(final List<String> permissions) {

    }

    @Override
    public void permissionsDenied(final List<String> permissions) {

    }
}
