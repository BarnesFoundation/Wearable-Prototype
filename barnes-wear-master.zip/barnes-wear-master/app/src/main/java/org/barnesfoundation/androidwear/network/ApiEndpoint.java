package org.barnesfoundation.androidwear.network;

import org.barnesfoundation.androidwear.model.AppConfig;
import org.barnesfoundation.androidwear.model.AuthResult;
import org.barnesfoundation.androidwear.model.DeviceId;
import org.barnesfoundation.androidwear.model.Item;
import org.barnesfoundation.androidwear.model.SavedItem;

import java.util.List;
import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface ApiEndpoint {
    //beware of the URL syntax
    //if starting with / it will make the request at the root
    //if not starting with / it will make the url at the full base url

    @FormUrlEncoded
    @POST("https://login.salesforce.com/services/oauth2/token")
    Call<AuthResult> login(@Field("grant_type") String grantType,
                           @Field("client_id") String clientId,
                           @Field("client_secret") String clientSecret,
                           @Field("username") String username,
                           @Field("password") String password);

    @POST
    Call<DeviceId> updateDeviceId(@Url String url,
                                  @Body Map<String, String> body);

    @POST
    Call<SavedItem> saveForLater(@Url String url,
                                 @Body Map<String, String> body);

    @GET
    Call<List<Item>> getItems(@Url String url,
                              @Query("uuid") String uuid);
    @GET
    Call<AppConfig> getConfig(@Url String url);
}
