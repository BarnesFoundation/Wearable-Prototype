package org.barnesfoundation.androidwear.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import org.barnesfoundation.androidwear.network.NetworkUtils;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class NetworkChangeReceiver extends BroadcastReceiver {

    private static final long MIN_UPDATE_DELAY = TimeUnit.MINUTES.toMillis(1);

    private static final AtomicBoolean WAITING = new AtomicBoolean(false);

    @Override
    public void onReceive(final Context context, final Intent intent) {

        if (!NetworkUtils.getConnectivityStatus()) {
            NetworkUtils.reconnectToFirstNetwork();
        }

        if (!WAITING.getAndSet(true)) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(MIN_UPDATE_DELAY);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    NetworkUtils.getNewtorkStatusMessage();
                    WAITING.set(false);
                }
            }).start();
        }
    }
}