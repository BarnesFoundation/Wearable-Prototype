package org.barnesfoundation.androidwear.utils;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class PermissionUtils {

    private static final AtomicInteger REQUEST_CODE_GENERATOR = new AtomicInteger(0);

    public static int generateNextRequestCode() {
        return REQUEST_CODE_GENERATOR.incrementAndGet();
    }

    public static void processPermissionsResult(
            final Permissionable permissionable,
            int requestCode,
            @NonNull String permissions[],
            @NonNull int[] grantResults) {


        if (requestCode == permissionable.getRequestCode()) {
            final List<String> grantedPermissions = new ArrayList<>();
            final List<String> deniedPermissions = new ArrayList<>();
            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    grantedPermissions.add(permissions[i]);
                } else {
                    deniedPermissions.add(permissions[i]);
                }
            }

            Log.d(">>> grantedPermissions: " + TextUtils.join(",", grantedPermissions));
            Log.d(">>> deniedPermissions: " + TextUtils.join(",", deniedPermissions));

            try {
                if (grantedPermissions.size() > 0) {
                    permissionable.permissionsGranted(grantedPermissions);
                }

                if (deniedPermissions.size() > 0) {
                    permissionable.permissionsDenied(deniedPermissions);
                }
            } catch (Exception e) {
                Log.e(e.getMessage());
            }
        }
    }

    public static boolean hasPermission(final String permission) {
        final boolean hasPermission = ContextCompat.checkSelfPermission(ApplicationData.getAppContext(), permission) == PackageManager.PERMISSION_GRANTED;
        Log.d(">>> hasPermission " + permission + " : " + hasPermission);
        return hasPermission;
    }

    public static void requestPermissions(final Permissionable permissionable, final String... args) {
        final int requestCode = permissionable.getRequestCode();
        if (permissionable instanceof Activity) {
            ActivityCompat.requestPermissions((Activity) permissionable, args, requestCode);
        } else if (permissionable instanceof Fragment) {
            ((Fragment) permissionable).requestPermissions(args, requestCode);
        }
    }

    public interface Permissionable {
        int getRequestCode();

        void permissionsGranted(final List<String> permissions);

        void permissionsDenied(final List<String> permissions);
    }
}
