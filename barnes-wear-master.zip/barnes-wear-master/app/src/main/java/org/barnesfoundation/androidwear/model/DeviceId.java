package org.barnesfoundation.androidwear.model;

import android.text.TextUtils;

public class DeviceId {
    public String localDeviceId = "";
    public String remoteDeviceId = "";

    public boolean isValid(){
        return !TextUtils.isEmpty(localDeviceId) && !TextUtils.isEmpty(remoteDeviceId);
    }
}
