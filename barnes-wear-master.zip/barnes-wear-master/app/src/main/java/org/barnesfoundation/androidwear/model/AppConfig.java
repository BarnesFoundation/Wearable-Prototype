package org.barnesfoundation.androidwear.model;

public class AppConfig {
    public long doubleDelayTimer1 = 30000;
    public long doubleDelayTimer2 = 15000;
}
