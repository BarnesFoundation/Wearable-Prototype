package org.barnesfoundation.androidwear.beacons;

import org.altbeacon.beacon.Beacon;
import org.barnesfoundation.androidwear.model.Item;

import java.util.ArrayList;
import java.util.List;

class BeaconMajorityHitDetection implements BeaconDetectionBehavior {

    private Beacon mLastBeacon;

    // List of the closest beacons found in previous scans
    private ArrayList<Beacon> mRecentBeacons = new ArrayList<>();

    // Number of beacons in mRecentBeacons that match the most recent beacons required to update
    // mLastBeacon and show notification
    private final int BEACON_THRESHOLD = 3;

    // Maximum number of beacons in mRecentBeacons
    private final int MAX_BEACONS_IN_LIST = 4;

    @Override
    public long getScanPeriod() {
        return 3000;
    }

    @Override
    public long getScanBetweenPeriod() {
        return 100;
    }

    @Override
    public String getDescription() {
        return "Double delay detection";
    }

    @Override
    public void newBeaconDetected(final Beacon beacon) {
        if (mLastBeacon == null) {
            mLastBeacon = beacon;
        }
        if (mRecentBeacons.size() == MAX_BEACONS_IN_LIST) {
            mRecentBeacons.remove(0);
        }
        mRecentBeacons.add(beacon);
        if (!isSameBeacon(beacon) && mRecentBeacons.size() == MAX_BEACONS_IN_LIST && hasMajorityBeaconChangedToNewBeacon(beacon)) {
            BeaconUtils.fetchItem(beacon);
            mLastBeacon = beacon;
        } else if (mRecentBeacons.size() == 1) {
            BeaconUtils.fetchItem(beacon);
        }
    }

    @Override
    public void itemsFetched(final Beacon beacon, final List<Item> items) {
        BeaconUtils.postItem(items, beacon);
    }

    private boolean isSameBeacon(final Beacon beacon) {
        return beacon != null && mLastBeacon != null && beacon.getId2().equals(mLastBeacon.getId2());
    }

    private boolean hasMajorityBeaconChangedToNewBeacon(Beacon newBeacon) {
        int count = 0;
        for (Beacon storedBeacon : mRecentBeacons) {
            if (storedBeacon.getId2().equals(newBeacon.getId2())) {
                count++;
            }
        }

        return count >= BEACON_THRESHOLD;
    }
}
