package org.barnesfoundation.androidwear.fragments;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.BitmapImageViewTarget;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.Target;

import org.barnesfoundation.androidwear.R;
import org.barnesfoundation.androidwear.event.ItemDiscoveredEvent;
import org.barnesfoundation.androidwear.event.SettingsEnabledEvent;
import org.barnesfoundation.androidwear.model.GenericError;
import org.barnesfoundation.androidwear.model.Item;
import org.barnesfoundation.androidwear.model.SavedItem;
import org.barnesfoundation.androidwear.network.ApiService;
import org.barnesfoundation.androidwear.network.ServiceCallback;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.barnesfoundation.androidwear.utils.AlertUtils;
import org.barnesfoundation.androidwear.utils.ApplicationData;
import org.barnesfoundation.androidwear.utils.JSONUtils;
import org.barnesfoundation.androidwear.utils.Log;
import org.barnesfoundation.androidwear.utils.NotificationUtils;
import org.barnesfoundation.androidwear.views.CustomImageView;
import org.barnesfoundation.androidwear.views.UnlockView;
import org.greenrobot.eventbus.EventBusException;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import static org.barnesfoundation.androidwear.storage.MiscPref.ObjectKey.SAVED_ITEM_CONFIRMATION_ALREADY_SHOWN;

public class PageMainFragment extends ScreenSlidePageFragment implements View.OnClickListener, UnlockView.OnUnlockedListener {

    private static final int SCROLL_Y_DISTANCE = 65;

    private ImageView mLogo;
    private CustomImageView mMainImage;
    private UnlockView mUnlockView;
    private View mNotificationContainer;
    private ScrollView mScrollView;
    private TextView mItemText;
    private Button mSaveForLater;
    private Button mDismiss;
    private ImageButton mUndo;

    private Item mItem;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_main, container, false);
        mLogo = (ImageView) rootView.findViewById(R.id.fragment_main_logo);
        mNotificationContainer = rootView.findViewById(R.id.fragment_main_notification_layout);
        mMainImage = (CustomImageView) rootView.findViewById(R.id.fragment_main_image);
        mUnlockView = (UnlockView) rootView.findViewById(R.id.fragment_main_unlock_view);
        mScrollView = (ScrollView) rootView.findViewById(R.id.fragment_main_scroll_view);
        mItemText = (TextView) rootView.findViewById(R.id.fragment_main_text);
        mSaveForLater = (Button) rootView.findViewById(R.id.fragment_main_save_for_later);
        mDismiss = (Button) rootView.findViewById(R.id.fragment_main_dismiss);
        mUndo = (ImageButton) rootView.findViewById(R.id.fragment_main_undo);

        mUndo.setVisibility(View.INVISIBLE);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mUnlockView.setUnlockedListener(this);
        mSaveForLater.setOnClickListener(this);
        mDismiss.setOnClickListener(this);
        mUndo.setOnClickListener(this);

        mNotificationContainer.setVisibility(View.INVISIBLE);
        mSaveForLater.setVisibility(MiscPref.getBooleanValue(MiscPref.ObjectKey.SAVE_FOR_LATER_DISABLED) ? View.GONE : View.VISIBLE);

        setupLastItem();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.fragment_main_save_for_later:
                saveForLater();
                break;
            case R.id.fragment_main_dismiss:
                setupItem(null, false);
                break;
            case R.id.fragment_main_undo:
                setupLastItem();
                break;
        }
    }

    private ItemDiscoveredEvent getLastDiscoveredEvent(){
        return ApplicationData.getEventBus().getStickyEvent(ItemDiscoveredEvent.class);
    }

    private void setupLastItem(){
        final ItemDiscoveredEvent stickyEvent = getLastDiscoveredEvent();
        if (stickyEvent != null) {
            setupItem(stickyEvent.items.get(0), false);
        }
    }

    private void saveForLater() {
        if (mItem != null && mItem.isValid()) {
//            mSaveForLater.setEnabled(false);
            setSaveForLaterTextAndState(R.string.saving_item);
            ApiService.saveForLater(mItem.id, new ServiceCallback<SavedItem>() {
                @Override
                public void onSuccess(SavedItem result) {
                    if (result != null && result.isValid()) {
//                        AlertUtils.showToast(R.string.item_saved);
                        if (!MiscPref.getBooleanValue(SAVED_ITEM_CONFIRMATION_ALREADY_SHOWN)) {
                            AlertUtils.showNeutralDialog(getActivity(), getString(R.string.item_saved), getString(R.string.item_saved_message));
                            MiscPref.setBooleanValue(SAVED_ITEM_CONFIRMATION_ALREADY_SHOWN, true);
                        }
                        setSaveForLaterTextAndState(R.string.item_saved);
                    } else {
//                        mSaveForLater.setEnabled(true);
                        setSaveForLaterTextAndState(R.string.save_for_later);
                    }
                }

                @Override
                public void onEror(GenericError error) {
//                    mSaveForLater.setEnabled(true);
                    setSaveForLaterTextAndState(R.string.save_for_later);
                }
            });
        }
    }

    private void setSaveForLaterTextAndState(int textId){
        mSaveForLater.setText(textId);
        mSaveForLater.setEnabled(textId == R.string.save_for_later);
    }

    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    public void itemDiscoveredEvent(final ItemDiscoveredEvent event) {
        setupItem(event.items.get(0), true);
    }

    @Override
    public void unlocked() {
        if (!MiscPref.getBooleanValue(MiscPref.ObjectKey.SETTINGS_ENABLED)) {
            ApplicationData.getEventBus().post(new SettingsEnabledEvent(true));
        }
    }

    private void setupItem(final Item item, final boolean vibrate) {
        try {
            if (item == null || !item.isValid()) {
                final ItemDiscoveredEvent stickyEvent = getLastDiscoveredEvent();
                mUndo.setVisibility(stickyEvent != null && stickyEvent.items.get(0).isValid() ? View.VISIBLE : View.INVISIBLE);
                animateItemOut();
            } else {
                downloadImage(item, vibrate);
            }
        } catch (Exception e) {
            Log.e(e.getMessage());
        }
    }

    private void downloadImage(final Item item, final boolean vibrate) {
        mMainImage.post(new Runnable() {
            @Override
            public void run() {
                Log.r("Downloading image for item: " + item.id);
                mMainImage.setImageSetCallback(new CustomImageView.OnImageSetCallback() {
                    @Override
                    public void imageSet(Drawable drawable) {
                        String drawableDescription = "";
                        try {
                            drawableDescription += " drawable: " + drawable;
                            drawableDescription += " image size: " + (drawable == null ? "0x0" : drawable.getIntrinsicWidth() + "x" + drawable.getIntrinsicHeight());
                        } catch (Exception e){

                        }

                        Log.r("Image downloaded for item: " + item.id + drawableDescription);
                        if (drawable != null){
                            showNotification(item, vibrate);
                        }
                    }
                });
                Glide.with(PageMainFragment.this)
                        .load(item.imageUrl)
                        .dontAnimate()
                        .into(new SimpleTarget<GlideDrawable>(mMainImage.getWidth(), mMainImage.getHeight()) {
                            @Override
                            public void onResourceReady(GlideDrawable resource, GlideAnimation<? super GlideDrawable> glideAnimation) {
                                mMainImage.setImageDrawable(resource);
                            }
                        });
            }
        });
    }

    private void showNotification(final Item item, final boolean vibrate){
        mUndo.setVisibility(View.INVISIBLE);
        mNotificationContainer.setVisibility(View.VISIBLE);
        mItemText.setText(item.description);
//        mSaveForLater.setEnabled(true);
        setSaveForLaterTextAndState(R.string.save_for_later);

        mItemText.post(new Runnable() {
            @Override
            public void run() {
                mScrollView.scrollTo(0, 0);
                mScrollView.smoothScrollBy(0, SCROLL_Y_DISTANCE);
            }
        });

        if (vibrate && (mItem == null || !mItem.equals(item))) {
            NotificationUtils.vibrate();
        }

        mItem = item;
    }

    private void animateItemOut(){
        if (mNotificationContainer.getVisibility() == View.VISIBLE){
            AnimationSet animationSet = new AnimationSet(true);
            animationSet.addAnimation(new AlphaAnimation(1.0f, 0.0f));
            animationSet.addAnimation(new TranslateAnimation(0, mNotificationContainer.getWidth(), 0, 0));
            animationSet.setInterpolator(new DecelerateInterpolator());
            animationSet.setDuration(400);
            animationSet.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {

                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    mNotificationContainer.setVisibility(View.INVISIBLE);
                    mScrollView.scrollTo(0, 0);
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });
            mNotificationContainer.startAnimation(animationSet);
        }
    }
}
