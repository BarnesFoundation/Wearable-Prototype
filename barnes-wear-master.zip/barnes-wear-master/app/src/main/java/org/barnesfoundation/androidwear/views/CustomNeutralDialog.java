package org.barnesfoundation.androidwear.views;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.StyleRes;
import android.view.View;
import android.widget.TextView;

import org.barnesfoundation.androidwear.R;

public class CustomNeutralDialog extends Dialog implements View.OnClickListener {

    private TextView mTitle;
    private TextView mMessage;
    private View mButton;

    public CustomNeutralDialog(Context context) {
        this(context, 0);
    }

    public CustomNeutralDialog(Context context, @StyleRes int themeResId) {
        super(context, themeResId);
        this.setContentView(R.layout.neutral_dialog);
        mTitle = (TextView) findViewById(R.id.neutral_dialog_title);
        mMessage = (TextView) findViewById(R.id.neutral_dialog_message);
        mButton = findViewById(R.id.neutral_dialog_button);

        mButton.setOnClickListener(this);
    }

    public void setMessage(String text) {
        mMessage.setText(text);
    }

    public void setTitle(String title) {
        mTitle.setText(title);
    }

    @Override
    public void onClick(View v) {
        dismiss();
    }

}