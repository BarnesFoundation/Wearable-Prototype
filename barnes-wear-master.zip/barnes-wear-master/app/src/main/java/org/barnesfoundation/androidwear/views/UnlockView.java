package org.barnesfoundation.androidwear.views;

import android.content.Context;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

public class UnlockView extends LinearLayout implements View.OnTouchListener {

    private static final long HIDDEN_VIEW_MAX_CLICK_INTERVAL = 600;

    private int mHiddenTopClickCount = 0;
    private int mHiddenBottomClickCount = 0;
    private long mHiddenLastClick = 0;

    private View mHiddenViewTop;
    private View mHiddenViewBottom;

    private OnUnlockedListener mUnlockedListener;

    public UnlockView(Context context) {
        super(context);
        init();
    }

    public UnlockView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public UnlockView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public void setUnlockedListener(final OnUnlockedListener unlockedListener) {
        mUnlockedListener = unlockedListener;
    }

    private void init() {
        setOrientation(VERTICAL);

        mHiddenViewTop = new View(getContext());
        mHiddenViewBottom = new View(getContext());

        mHiddenViewTop.setOnTouchListener(this);
        mHiddenViewBottom.setOnTouchListener(this);

        final LinearLayout.LayoutParams topParams = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0);
        topParams.weight = 1;
        final LinearLayout.LayoutParams bottomParams = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0);
        bottomParams.weight = 1;

        addView(mHiddenViewTop, topParams);
        addView(mHiddenViewBottom, bottomParams);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            hiddenViewClicked(v);
        }
        return false;
    }

    private void hiddenViewClicked(final View view) {
        final long currentTime = SystemClock.elapsedRealtime();
        if (currentTime - mHiddenLastClick >= HIDDEN_VIEW_MAX_CLICK_INTERVAL) {
            mHiddenTopClickCount = 0;
            mHiddenBottomClickCount = 0;
        }
        mHiddenLastClick = currentTime;

        //sequence: 2 clicks on the bottom view and 3 on the top
        if (view == mHiddenViewTop) {
            mHiddenTopClickCount++;
        } else {
            mHiddenTopClickCount = 0;
            mHiddenBottomClickCount++;
        }

        final boolean unlocked = mHiddenBottomClickCount == 2 && mHiddenTopClickCount == 3;
        if (unlocked && mUnlockedListener != null) {
            mUnlockedListener.unlocked();
        }
    }

    public interface OnUnlockedListener {
        void unlocked();
    }
}
