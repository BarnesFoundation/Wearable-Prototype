package org.barnesfoundation.androidwear.kiosk;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.barnesfoundation.androidwear.activities.BaseActivity;
import org.barnesfoundation.androidwear.activities.MainActivity;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.barnesfoundation.androidwear.utils.ApplicationData;

import java.util.concurrent.TimeUnit;

public class KioskUtils {

    private static final long ALARM_INTERVAL = TimeUnit.SECONDS.toMillis(30);

    public static void setupAlarm() {
        final Context context = ApplicationData.getAppContext();
        final AlarmManager alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        final Intent intent = new Intent(context, AlarmReceiver.class);
        final PendingIntent alarmIntent = PendingIntent.getBroadcast(context, 0, intent, 0);
        final long alarmFirstTrigger = System.currentTimeMillis() + ALARM_INTERVAL;
        alarmMgr.setRepeating(AlarmManager.RTC_WAKEUP, alarmFirstTrigger, ALARM_INTERVAL, alarmIntent);
    }

    public static void checkAndRestartMainActivity() {
        if (!MiscPref.getBooleanValue(MiscPref.ObjectKey.AUTO_RESUME_APP_DISABLED)
                && !BaseActivity.isVisible(MainActivity.class)) {
            final Context context = ApplicationData.getAppContext();
            final Intent intent = new Intent(context, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        }
    }
}
