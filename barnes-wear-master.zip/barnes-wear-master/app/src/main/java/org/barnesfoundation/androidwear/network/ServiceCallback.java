package org.barnesfoundation.androidwear.network;

import org.barnesfoundation.androidwear.model.GenericError;

public interface ServiceCallback<T1> {
    void onSuccess(T1 result);

    void onEror(GenericError error);

    class Call {
        public static <T1> void onSuccess(ServiceCallback<T1> callback, T1 obj) {
            if (callback != null) {
                callback.onSuccess(obj);
            }
        }

        public static <T1> void onError(ServiceCallback<T1> callback, GenericError error) {
            if (callback != null) {
                callback.onEror(error);
            }
        }
    }
}