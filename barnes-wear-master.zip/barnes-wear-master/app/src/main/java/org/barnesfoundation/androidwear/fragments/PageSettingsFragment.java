package org.barnesfoundation.androidwear.fragments;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import org.barnesfoundation.androidwear.R;
import org.barnesfoundation.androidwear.event.SettingsEnabledEvent;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.barnesfoundation.androidwear.utils.AlertUtils;
import org.barnesfoundation.androidwear.utils.ApplicationData;
import org.barnesfoundation.androidwear.beacons.BeaconUtils;
import org.barnesfoundation.androidwear.utils.Log;

import static org.barnesfoundation.androidwear.storage.MiscPref.ObjectKey.SAVED_ITEMS_MAP;
import static org.barnesfoundation.androidwear.storage.MiscPref.ObjectKey.SAVED_ITEM_CONFIRMATION_ALREADY_SHOWN;

public class PageSettingsFragment extends ScreenSlidePageFragment implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {

    private CheckBox mSaveForLaterCheckbox;
    private CheckBox mBeaconsMonitoringCheckbox;
    private CheckBox mAdminModeCheckbox;
    private CheckBox mAutoResumeAppCheckbox;
    private CheckBox mShowMultipleItemsCheckbox;
    private Button mClearSessionButton;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_settings, container, false);
        mSaveForLaterCheckbox = (CheckBox) rootView.findViewById(R.id.fragment_settings_show_save_for_later);
        mBeaconsMonitoringCheckbox = (CheckBox) rootView.findViewById(R.id.fragment_settings_beacons_monitoring);
        mAdminModeCheckbox = (CheckBox) rootView.findViewById(R.id.fragment_settings_admin_mode);
        mAutoResumeAppCheckbox = (CheckBox) rootView.findViewById(R.id.fragment_settings_auto_resume_app);
        mShowMultipleItemsCheckbox = (CheckBox) rootView.findViewById(R.id.fragment_settings_show_multiple_items);
        mClearSessionButton = (Button) rootView.findViewById(R.id.fragment_settings_clear_session);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mClearSessionButton.setOnClickListener(this);


    }

    @Override
    public void onResume() {
        super.onResume();
        loadInitialValues();
    }

    private void loadInitialValues() {
        mSaveForLaterCheckbox.setChecked(!MiscPref.getBooleanValue(MiscPref.ObjectKey.SAVE_FOR_LATER_DISABLED));
        mBeaconsMonitoringCheckbox.setChecked(!MiscPref.getBooleanValue(MiscPref.ObjectKey.BEACON_MONITORING_DISABLED));
        mAdminModeCheckbox.setChecked(MiscPref.getBooleanValue(MiscPref.ObjectKey.SETTINGS_ENABLED));
        mAutoResumeAppCheckbox.setChecked(!MiscPref.getBooleanValue(MiscPref.ObjectKey.AUTO_RESUME_APP_DISABLED));
        mShowMultipleItemsCheckbox.setChecked(!MiscPref.getBooleanValue(MiscPref.ObjectKey.SHOW_MULTIPLE_ITEMS_DISABLED));

        mSaveForLaterCheckbox.setOnCheckedChangeListener(this);
        mBeaconsMonitoringCheckbox.setOnCheckedChangeListener(this);
        mAdminModeCheckbox.setOnCheckedChangeListener(this);
        mAutoResumeAppCheckbox.setOnCheckedChangeListener(this);
        mShowMultipleItemsCheckbox.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(final CompoundButton compoundButton, final boolean checked) {
        switch (compoundButton.getId()) {
            case R.id.fragment_settings_beacons_monitoring:
                MiscPref.setBooleanValue(MiscPref.ObjectKey.BEACON_MONITORING_DISABLED, !checked);
                if (checked) {
                    ((ApplicationData) ApplicationData.getAppContext()).startRanging(ApplicationData.BEACONS_UUID);
                } else {
                    ((ApplicationData) ApplicationData.getAppContext()).stopRanging(ApplicationData.BEACONS_UUID);
                }
                break;
            case R.id.fragment_settings_admin_mode:
                ApplicationData.getEventBus().post(new SettingsEnabledEvent(checked));
                break;
            case R.id.fragment_settings_auto_resume_app:
                MiscPref.setBooleanValue(MiscPref.ObjectKey.AUTO_RESUME_APP_DISABLED, !checked);
                break;
            case R.id.fragment_settings_show_multiple_items:
                MiscPref.setBooleanValue(MiscPref.ObjectKey.SHOW_MULTIPLE_ITEMS_DISABLED, !checked);
                break;
            case R.id.fragment_settings_show_save_for_later:
                AlertUtils.showAcceptDenyDialog(getActivity(),
                        getString(checked ? R.string.show_save_for_later : R.string.hide_save_for_later), null,
                        getString(checked ? R.string.show_save_for_later_success : R.string.hide_save_for_later_success),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == DialogInterface.BUTTON_POSITIVE) {
                                    MiscPref.setBooleanValue(MiscPref.ObjectKey.SAVE_FOR_LATER_DISABLED, !checked);
                                } else {
                                    compoundButton.setOnCheckedChangeListener(null);
                                    compoundButton.setChecked(!checked);
                                    compoundButton.setOnCheckedChangeListener(PageSettingsFragment.this);
                                }
                            }
                        }
                );
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fragment_settings_clear_session:
                AlertUtils.showAcceptDenyDialog(getActivity(),
                        getString(R.string.clear_session_title), null,
                        getString(R.string.clear_session_success),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == DialogInterface.BUTTON_POSITIVE) {
                                    Log.flushReporter();
                                    MiscPref.deleteObject(SAVED_ITEM_CONFIRMATION_ALREADY_SHOWN);
                                    MiscPref.deleteObject(SAVED_ITEMS_MAP);
                                    BeaconUtils.resetSession();
                                }
                            }
                        }
                );
                break;
        }
    }
}
