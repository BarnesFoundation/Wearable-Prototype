package org.barnesfoundation.androidwear.fragments;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.view.View;

import org.barnesfoundation.androidwear.network.NetworkUtils;
import org.barnesfoundation.androidwear.utils.ApplicationData;
import org.barnesfoundation.androidwear.utils.Log;

public class PageNetworkStatusFragment extends ScreenSlidePageFragment {
    private static final long MONITOR_INTERVAL = 10000;

    private final Handler networkHandler = new Handler();
    private final Runnable networkRunnable = new Runnable() {
        @Override
        public void run() {
            setNetworkStatus();
            networkHandler.postDelayed(networkRunnable, MONITOR_INTERVAL);
        }
    };

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        networkHandler.post(networkRunnable);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        networkHandler.removeCallbacksAndMessages(null);
    }

    private void setNetworkStatus() {
        setText(NetworkUtils.getNewtorkStatusMessage());
    }


}
