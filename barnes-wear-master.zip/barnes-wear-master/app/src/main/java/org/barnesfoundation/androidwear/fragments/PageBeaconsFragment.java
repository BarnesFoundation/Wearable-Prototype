package org.barnesfoundation.androidwear.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import org.barnesfoundation.androidwear.event.BeaconsFoundEvent;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.barnesfoundation.androidwear.beacons.BeaconUtils;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class PageBeaconsFragment extends ScreenSlidePageFragment {

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (MiscPref.getBooleanValue(MiscPref.ObjectKey.BEACON_MONITORING_DISABLED)) {
            setText("Monitoring disabled");
        } else {
            setText("Waiting detection...");
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onBeaconsFoundEvent(final BeaconsFoundEvent beaconsFoundEvent) {
        setText(BeaconUtils.getBeaconsList(beaconsFoundEvent.collection));
    }
}
