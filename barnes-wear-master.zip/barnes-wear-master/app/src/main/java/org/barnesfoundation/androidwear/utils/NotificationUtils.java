package org.barnesfoundation.androidwear.utils;

import android.app.Notification;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Vibrator;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;

import org.barnesfoundation.androidwear.R;
import org.barnesfoundation.androidwear.event.ItemDiscoveredEvent;
import org.barnesfoundation.androidwear.model.Item;

import java.util.List;

public class NotificationUtils {

    private static final int NOTIFICATION_ID = 1000;
    private static final int IMAGE_SIZE = 480;

    public static void showNotification(final List<Item> items) {
        Log.d(">>> NotificationUtils showNotification: " + (items == null ? "null" : items.toString()));
        if (items != null && items.size() > 0) {
            ApplicationData.getEventBus().postSticky(new ItemDiscoveredEvent(items));
//            new AsyncTask<Void, Void, Bitmap>() {
//                @Override
//                protected Bitmap doInBackground(Void... params) {
//                    try {
//                        final RequestManager requestManager = Glide.with(ApplicationData.getAppContext());
//                        return requestManager.load(item.imageUrl).asBitmap().into(IMAGE_SIZE, IMAGE_SIZE).get();
//                    } catch (Exception e) {
//                        return null;
//                    }
//                }
//
//                @Override
//                protected void onPostExecute(Bitmap bitmap) {
//                    showNotification(item, bitmap);
//                }
//            }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        }
    }

    public static void showNotification(final Item item, final Bitmap bitmap) {
        if (item != null && item.isValid()) {
            final Context context = ApplicationData.getAppContext();

//            final Intent displayIntent = new Intent(context, DetailsActivity.class);
//            displayIntent.putExtra(DetailsActivity.ITEM_EXTRA, JSONUtils.toString(item));
//            final PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, displayIntent,
//                    PendingIntent.FLAG_UPDATE_CURRENT);

            final NotificationCompat.WearableExtender wearableExtender =
                    new NotificationCompat.WearableExtender()
                            .setBackground(bitmap);


            final NotificationCompat.BigPictureStyle secondPageStyle = new NotificationCompat.BigPictureStyle();
            secondPageStyle.bigPicture(bitmap);

            final Notification secondPageNotification = new NotificationCompat.Builder(context)
                    .setStyle(secondPageStyle)
                    .extend(wearableExtender.setHintShowBackgroundOnly(true))
                    .build();

            wearableExtender.addPage(secondPageNotification);

            final Notification notif = new NotificationCompat.Builder(context)
                    .setContentTitle(item.name)
                    .setSmallIcon(R.mipmap.ic_launcher)
//                    .setContentIntent(pendingIntent)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(item.description))
                    .setPriority(Notification.PRIORITY_MAX)
                    .extend(wearableExtender)
                    .build();

            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
            notificationManager.notify(NOTIFICATION_ID, notif);

            vibrate();
        }
    }

    public static void vibrate(){
        try {
            final Context context = ApplicationData.getAppContext();
            //force vibration
            Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            v.vibrate(1500);
        } catch (Exception e) {
            Log.e(e.getMessage());
        }
    }
}
