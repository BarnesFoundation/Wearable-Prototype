package org.barnesfoundation.androidwear.network;

import org.barnesfoundation.androidwear.model.GenericError;
import org.barnesfoundation.androidwear.utils.Log;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NetworkCallback<T1> implements Callback<T1> {


    public NetworkCallback() {
    }

    @Override
    public void onResponse(Call<T1> call, Response<T1> response) {
        try {
            if (response.isSuccessful()) {
                success(response.body(), response.code());
            } else {
                final GenericError error = NetworkUtils.parseError(response.errorBody());
                error(error);
            }
        } catch (Exception e) {
            Log.e(e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void onFailure(Call<T1> call, Throwable t) {
        Log.e(t.getMessage());
        Log.r(t.getMessage());
        try {
            error(new GenericError());
        } catch (Exception e) {
            error(null);
        }
    }

    public void success(T1 response, int code) {
    }

    public void error(GenericError error) {
    }
}
