package org.barnesfoundation.androidwear.model;

public class GenericError {
    public String errorCode = "";
    public String message = "";
}
