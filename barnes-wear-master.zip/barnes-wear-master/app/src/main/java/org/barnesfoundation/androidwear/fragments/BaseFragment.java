package org.barnesfoundation.androidwear.fragments;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;

import org.barnesfoundation.androidwear.utils.ApplicationData;
import org.greenrobot.eventbus.Subscribe;

import java.util.concurrent.atomic.AtomicBoolean;

public class BaseFragment extends Fragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        registerEventBus();
    }

    @Override
    public void onDestroy() {
        unregisterEventBus();
        super.onDestroy();
    }

    public void registerEventBus(){
        try {
            ApplicationData.getEventBus().register(this);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void unregisterEventBus(){
        try {
            ApplicationData.getEventBus().unregister(this);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    @Subscribe
    public void anyEvent(AtomicBoolean value) {
        //empty event just to avoid error
    }
}
