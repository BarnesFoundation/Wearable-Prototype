package org.barnesfoundation.androidwear.beacons;

import org.altbeacon.beacon.Beacon;
import org.barnesfoundation.androidwear.model.Item;

import java.util.List;

public class BeaconSimpleDetection implements BeaconDetectionBehavior {

    @Override
    public long getScanPeriod() {
        return 5000;
    }

    @Override
    public long getScanBetweenPeriod() {
        return 5000;
    }

    @Override
    public String getDescription() {
        return "Simple detection";
    }

    @Override
    public void newBeaconDetected(Beacon beacon) {
        BeaconUtils.fetchItem(beacon);
    }

    @Override
    public void itemsFetched(Beacon beacon, List<Item> items) {
        BeaconUtils.postItem(items, beacon);
    }
}
