package org.barnesfoundation.androidwear.network;

import org.barnesfoundation.androidwear.BuildConfig;
import org.barnesfoundation.androidwear.model.DeviceId;
import org.barnesfoundation.androidwear.storage.MiscPref;
import org.barnesfoundation.androidwear.utils.BuildConstants;
import org.barnesfoundation.androidwear.utils.LogReporter;

import java.io.File;
import java.util.Date;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class LogUploadService {
    private static final LogUploadEndpoint API;

    static {
        final Retrofit.Builder builder = new Retrofit.Builder();
        if (BuildConfig.WRITE_LOGS) {
            builder.client(new OkHttpClient.Builder()
                    .addInterceptor(new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
                    .build());
        }
        builder.baseUrl(BuildConstants.LOG_BASE_URL);
        API = builder.build().create(LogUploadEndpoint.class);
    }

    public static void uploadLogFile(final File file, final String fileName, final String description) {
        final RequestBody descriptionBody = okhttp3.RequestBody.create(MediaType.parse("multipart/form-data"), description);
        final MultipartBody.Part filePart = MultipartBody.Part.createFormData(
                LogUploadEndpoint.LOG_FILE_FIELD_NAME, fileName,
                okhttp3.RequestBody.create(MediaType.parse("multipart/form-data"), file));

        API.uploadLog(BuildConstants.LOG_UPLOAD_URL,
                descriptionBody, filePart)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        file.delete();
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {

                    }
                });

    }

    public static void uploadAllLogs(final File parentDir) {
        final DeviceId savedDeviceId = MiscPref.getObject(MiscPref.ObjectKey.DEVICE_ID, DeviceId.class);

        for (String fileName : parentDir.list()) {
            final File currentFile = new File(parentDir, fileName);

            final String description = "Barnes log file from device id (Local: " + savedDeviceId.localDeviceId
                    + ", Remote: " + savedDeviceId.remoteDeviceId + ".\n"
                    + "File generated at " + LogReporter.SDF.format(new Date(currentFile.lastModified()));

            LogUploadService.uploadLogFile(currentFile, savedDeviceId.remoteDeviceId + "-" + fileName, description);
        }
    }
}
