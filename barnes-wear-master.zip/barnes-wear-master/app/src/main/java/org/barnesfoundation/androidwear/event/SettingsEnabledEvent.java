package org.barnesfoundation.androidwear.event;

public class SettingsEnabledEvent {
    public boolean enabled;

    public SettingsEnabledEvent(boolean enabled) {
        this.enabled = enabled;
    }
}
